#!/usr/bin/env bash
# 봇을 포그라운드로 실행한다. venv 활성화 + DB 마이그레이션을 자동으로 처리한다.
# 사용: ./scripts/run.sh
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d .venv ]; then
  echo "가상환경이 없습니다. 먼저 만드세요:"
  echo "  python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

source .venv/bin/activate
alembic upgrade head
exec python -m app.main
