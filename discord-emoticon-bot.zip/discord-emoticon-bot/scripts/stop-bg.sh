#!/usr/bin/env bash
# start-bg.sh 로 띄운 봇을 중지한다.
# 사용: ./scripts/stop-bg.sh
set -euo pipefail
cd "$(dirname "$0")/.."

PIDFILE="data/bot.pid"
if [ ! -f "$PIDFILE" ]; then
  echo "실행 중인 프로세스 기록이 없습니다."
  exit 0
fi

PID="$(cat "$PIDFILE")"
if kill -0 "$PID" 2>/dev/null; then
  kill "$PID"
  echo "중지 요청을 보냈습니다 (PID $PID)."
else
  echo "프로세스가 이미 종료되어 있습니다."
fi
rm -f "$PIDFILE"
