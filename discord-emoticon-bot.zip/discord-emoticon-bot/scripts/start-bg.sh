#!/usr/bin/env bash
# 봇을 백그라운드로 실행한다(nohup). 로그는 data/bot.log 에 쌓인다.
# systemd 를 쓸 수 없는 환경(권한 없는 서버 등)에서 간단히 돌릴 때 쓴다.
# 사용: ./scripts/start-bg.sh
set -euo pipefail
cd "$(dirname "$0")/.."

PIDFILE="data/bot.pid"
LOGFILE="data/bot.log"
mkdir -p data

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "이미 실행 중입니다 (PID $(cat "$PIDFILE")). 먼저 ./scripts/stop-bg.sh 로 중지하세요."
  exit 1
fi

source .venv/bin/activate
alembic upgrade head

nohup python -m app.main >> "$LOGFILE" 2>&1 &
echo $! > "$PIDFILE"
echo "백그라운드 실행 시작 (PID $(cat "$PIDFILE"))."
echo "로그 보기:  tail -f $LOGFILE"
echo "중지:       ./scripts/stop-bg.sh"
