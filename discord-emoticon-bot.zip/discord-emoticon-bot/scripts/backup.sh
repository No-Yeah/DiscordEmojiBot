#!/usr/bin/env bash
#
# 설정/데이터 백업. .env 와 이미지·DB 를 zip 하나로 묶는다.
# git pull / 재설치로 코드가 바뀌어도 이 zip 만 있으면 복구된다.
#
#   ./scripts/backup.sh              → backups/ 아래 타임스탬프 zip 생성
#   ./scripts/backup.sh /path/out.zip
#
set -euo pipefail
cd "$(dirname "$0")/.."
PROJECT_DIR="$(pwd)"

ENV_FILE="$PROJECT_DIR/.env"
[ -f "$ENV_FILE" ] || { echo ".env 가 없습니다. 백업할 게 없습니다."; exit 1; }

# .env 에서 실제 이미지/DB 경로를 읽어온다
STORAGE_DIR="$(grep -E '^STORAGE_DIR=' "$ENV_FILE" | cut -d= -f2- || true)"
DB_URL="$(grep -E '^DATABASE_URL=' "$ENV_FILE" | cut -d= -f2- || true)"
DB_PATH="$(printf '%s' "$DB_URL" | sed -E 's#^sqlite\+aiosqlite:///##')"

TS="$(date +%Y%m%d_%H%M%S)"
OUT="${1:-$PROJECT_DIR/backups/backup_$TS.zip}"
mkdir -p "$(dirname "$OUT")"

command -v zip >/dev/null || { echo "zip 이 없습니다:  sudo apt install -y zip"; exit 1; }

# 임시 목록 구성
FILES=(".env")
[ -n "$STORAGE_DIR" ] && [ -d "$STORAGE_DIR" ] && FILES+=("$STORAGE_DIR")
[ -n "$DB_PATH" ] && [ -f "$DB_PATH" ] && FILES+=("$DB_PATH")
# WAL/SHM 파일도(있으면)
[ -f "${DB_PATH}-wal" ] && FILES+=("${DB_PATH}-wal")
[ -f "${DB_PATH}-shm" ] && FILES+=("${DB_PATH}-shm")

echo "백업 대상:"
printf '  - %s\n' "${FILES[@]}"

# 절대경로가 섞일 수 있으므로 -y(심링크 보존) 없이 그대로 저장
zip -rq "$OUT" "${FILES[@]}"
echo
echo "완료: $OUT"
echo "복구:  unzip -o \"$OUT\" -d /   (경로 그대로 덮어씀 — 주의해서 사용)"
