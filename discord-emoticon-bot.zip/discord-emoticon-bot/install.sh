#!/usr/bin/env bash
#
# 원클릭 설치 스크립트.
#   git clone <repo> && cd <repo> && sudo ./install.sh
#
# 하는 일:
#   1. 시스템 의존성(python3-venv 등) 확인·설치
#   2. venv 생성 + requirements 설치
#   3. .env 없으면 봇 토큰/이미지 폴더를 물어보고 생성 (있으면 건너뜀)
#   4. DB 마이그레이션
#   5. systemd 서비스 2개(봇 + 태깅 웹) 생성·등록·시작
#      - 태깅 웹은 0.0.0.0 으로 바인딩
#   6. 재실행해도 안전(idempotent). .env 와 data 는 절대 건드리지 않음.
#
set -euo pipefail

# --- 경로/상수 ---
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$PROJECT_DIR/.venv"
ENV_FILE="$PROJECT_DIR/.env"
PY="$VENV/bin/python"
SERVICE_USER="${SUDO_USER:-root}"
BOT_SERVICE="emoticon-bot"
TAG_SERVICE="emoticon-tagging"

info()  { printf '\033[1;34m[*]\033[0m %s\n' "$*"; }
ok()    { printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
warn()  { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die()   { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "root 로 실행하세요:  sudo ./install.sh"

# ─────────────────────────────────────────────────────────────
# 1. 시스템 의존성
# ─────────────────────────────────────────────────────────────
info "시스템 패키지 확인"
NEED_PKG=()
command -v python3 >/dev/null || NEED_PKG+=(python3)
python3 -c "import venv" 2>/dev/null || NEED_PKG+=(python3-venv)
python3 -c "import ensurepip" 2>/dev/null || NEED_PKG+=(python3-venv)
command -v git >/dev/null || NEED_PKG+=(git)

if [ "${#NEED_PKG[@]}" -gt 0 ]; then
  info "설치 필요: ${NEED_PKG[*]}"
  if command -v apt-get >/dev/null; then
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${NEED_PKG[@]}"
  else
    die "apt 계열이 아닙니다. 수동으로 ${NEED_PKG[*]} 설치 후 다시 실행하세요."
  fi
fi
ok "시스템 패키지 준비 완료"

# ─────────────────────────────────────────────────────────────
# 2. venv + requirements
# ─────────────────────────────────────────────────────────────
if [ ! -x "$PY" ]; then
  info "가상환경(.venv) 생성"
  python3 -m venv "$VENV"
fi
info "의존성 설치 (requirements.txt)"
"$PY" -m pip install --quiet --upgrade pip
"$PY" -m pip install --quiet -r "$PROJECT_DIR/requirements.txt"
ok "파이썬 의존성 준비 완료"

# ─────────────────────────────────────────────────────────────
# 3. .env (있으면 그대로 둔다 — 토큰/설정 유실 방지)
# ─────────────────────────────────────────────────────────────
if [ -f "$ENV_FILE" ]; then
  ok ".env 가 이미 있어 그대로 사용합니다 (토큰/설정 유지)"
else
  info ".env 를 새로 만듭니다. 아래 값을 입력하세요."

  # 봇 토큰 (필수)
  TOKEN=""
  while [ -z "$TOKEN" ]; do
    read -rp "  Discord 봇 토큰: " TOKEN </dev/tty
    [ -z "$TOKEN" ] && warn "토큰은 필수입니다."
  done

  # 이미지 저장 폴더 (기본값 제공, 없으면 자동 생성됨)
  DEFAULT_IMG="$PROJECT_DIR/data/images"
  read -rp "  이미지 저장 폴더 [$DEFAULT_IMG]: " IMG_DIR </dev/tty
  IMG_DIR="${IMG_DIR:-$DEFAULT_IMG}"
  mkdir -p "$IMG_DIR"

  # DB 파일 위치 (이미지 폴더 옆 data 아래)
  DB_DIR="$(dirname "$IMG_DIR")"
  mkdir -p "$DB_DIR"
  DB_PATH="$DB_DIR/emoticon.db"

  # 개발용 길드 ID (선택)
  read -rp "  테스트 서버 ID (없으면 Enter): " GUILD </dev/tty

  umask 077   # .env 는 소유자만 읽게
  cat > "$ENV_FILE" <<EOF
# 이 파일은 install.sh 가 생성했습니다. 토큰이 들어있으니 공유/커밋 금지.
DISCORD_BOT_TOKEN=$TOKEN
DISCORD_DEV_GUILD_ID=$GUILD

SEND_STYLE=image
APP_EMOJI_ENABLED=false

DATABASE_URL=sqlite+aiosqlite:///$DB_PATH
STORAGE_DIR=$IMG_DIR
IMAGE_SIZE=512

# 태깅 웹: 외부에서 접속 가능하게 0.0.0.0 바인딩 (인증 없음 — 방화벽/프록시로 보호)
TAGGING_HOST=0.0.0.0
TAGGING_PORT=8000

ALLOW_PRIVATE_NETWORK=false
LOG_LEVEL=INFO
EOF
  chmod 600 "$ENV_FILE"
  ok ".env 생성 완료 (이미지 폴더: $IMG_DIR)"
fi

# .env 소유자를 실행 사용자로 (root 소유로 남아도 서비스는 root 실행이라 무방)
chown "$SERVICE_USER":"$SERVICE_USER" "$ENV_FILE" 2>/dev/null || true

# ─────────────────────────────────────────────────────────────
# 4. DB 마이그레이션
# ─────────────────────────────────────────────────────────────
info "데이터베이스 준비 (alembic upgrade head)"
( cd "$PROJECT_DIR" && "$VENV/bin/alembic" upgrade head )
ok "DB 준비 완료"

# ─────────────────────────────────────────────────────────────
# 5. systemd 서비스 생성
# ─────────────────────────────────────────────────────────────
info "systemd 서비스 생성"

cat > "/etc/systemd/system/${BOT_SERVICE}.service" <<EOF
[Unit]
Description=Discord Emoticon Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR
EnvironmentFile=$ENV_FILE
ExecStartPre=$VENV/bin/alembic upgrade head
ExecStart=$PY -m app.main
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

cat > "/etc/systemd/system/${TAG_SERVICE}.service" <<EOF
[Unit]
Description=Discord Emoticon Tagging Web
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$PY -m app.tagging.server
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now "${BOT_SERVICE}.service"
systemctl enable --now "${TAG_SERVICE}.service"
ok "서비스 등록·시작 완료"

# ─────────────────────────────────────────────────────────────
# 6. 마무리 안내
# ─────────────────────────────────────────────────────────────
sleep 2
TAG_PORT="$(grep -E '^TAGGING_PORT=' "$ENV_FILE" | cut -d= -f2)"
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"

echo
ok "설치 완료!"
echo "────────────────────────────────────────────"
echo "  봇 상태:      systemctl status $BOT_SERVICE"
echo "  봇 로그:      journalctl -u $BOT_SERVICE -f"
echo "  태깅 상태:    systemctl status $TAG_SERVICE"
echo "  태깅 페이지:  http://${IP:-<서버IP>}:${TAG_PORT:-8000}"
echo
echo "  설정 백업:    ./scripts/backup.sh   (.env + data 를 zip 으로)"
echo "  업데이트:     git pull && sudo ./install.sh   (.env/data 유지)"
echo "────────────────────────────────────────────"

if ! systemctl is-active --quiet "$BOT_SERVICE"; then
  warn "봇이 아직 실행 중이 아닙니다. 토큰이 맞는지 로그를 확인하세요:"
  echo "    journalctl -u $BOT_SERVICE -n 30 --no-pager"
fi
