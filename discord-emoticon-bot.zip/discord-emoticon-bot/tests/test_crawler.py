from __future__ import annotations

import pytest

from app.crawler.base import get_parser
from app.crawler.fetcher import FetchError, assert_safe_url
from app.crawler.generic import GenericImageParser
from app.crawler.kakao import KakaoEmoticonParser


@pytest.fixture(autouse=True)
def _block_private(monkeypatch):
    # .env 값에 관계없이 SSRF 방어가 켜진 상태를 보장한다
    from app.config import settings

    monkeypatch.setattr(settings, "allow_private_network", False)


@pytest.mark.parametrize(
    "url",
    [
        "http://127.0.0.1/x.png",
        "http://localhost/x.png",
        "http://169.254.169.254/latest/meta-data/",  # 클라우드 메타데이터
        "http://[::1]/x.png",
        "file:///etc/passwd",
        "ftp://example.com/x.png",
        "http://user:pw@example.com/x.png",
        "http://example.com:22/x.png",
    ],
)
def test_assert_safe_url_blocks_dangerous(url):
    with pytest.raises(FetchError):
        assert_safe_url(url)


def test_assert_safe_url_allows_public_https():
    assert assert_safe_url("https://example.com/a.png").startswith("https://")


def test_parser_selection():
    assert isinstance(get_parser("https://e.kakao.com/t/abc"), KakaoEmoticonParser)
    assert isinstance(get_parser("https://example.com/page"), GenericImageParser)


def _kakao_page(pack_prefix: str, pack_count: int, noise: list[str]) -> str:
    """실제 카카오 페이지 구조를 흉내낸다: 본품 pack_count개(같은 prefix) + 잡음."""
    items = "".join(
        f'<img src="https://item.kakaocdn.net/do/{pack_prefix}{i:032x}-g?_v=_R_{i}x_-0-0">'
        for i in range(pack_count)
    )
    noise_imgs = "".join(f'<img src="{u}">' for u in noise)
    return f"<html><title>마루는 강쥐</title><body>{items}{noise_imgs}</body></html>"


def test_kakao_parser_selects_pack_by_shared_prefix():
    prefix = "d67387137ba0ea78d04c1427aba7bf10"  # 32 hex, 본품 공통
    noise = [
        # 대표 이미지(og) - prefix 다름
        "https://item.kakaocdn.net/do/4e86c5076769b37c10aade6c8a0fc47fdca0edec0d9981e61b3ffe9f12b409b4-g?_v=_R_2x_-0-0",
        # 관련상품 - prefix 다름
        "https://item.kakaocdn.net/do/f8c09d5a83300011938c0674e534c7fbdca0edec0d9981e61b3ffe9f12b409b4",
        # 작가 프로필 - prefix 다름
        "https://item.kakaocdn.net/do/63860ecc88cedd41e8a0393ea36989986a1a0d693d37ada0214ed88347a02be3",
        # UI 에셋(svg, t1 도메인)
        "https://t1.kakaocdn.net/estore/artifacts/3.0.3/assets/menu-24-Br76thLP.svg",
    ]
    page = _kakao_page(prefix, 24, noise)
    found = KakaoEmoticonParser().extract(page, "https://e.kakao.com/t/maru")

    assert len(found) == 24                       # 본품 24개만
    assert all(prefix in c.url for c in found)     # 전부 본품 prefix
    assert all("/estore/artifacts/" not in c.url for c in found)  # 에셋 제외
    assert found[0].title == "마루는 강쥐"


def test_kakao_parser_deduplicates_same_image_query_variants():
    prefix = "a" * 32
    # 같은 이미지의 다른 _v 쿼리스트링은 하나로 취급되어야 한다
    dup = f"{prefix}{'b' * 32}"
    page = (
        f'<html><body>'
        f'<img src="https://item.kakaocdn.net/do/{dup}-g?_v=_R_1x_-0-0">'
        f'<img src="https://item.kakaocdn.net/do/{dup}-g?_v=_R_9x_-0-0">'
        f'<img src="https://item.kakaocdn.net/do/{prefix}{"c" * 32}-g?_v=_R_2x_-0-0">'
        f'<img src="https://item.kakaocdn.net/do/{prefix}{"d" * 32}-g?_v=_R_3x_-0-0">'
        f'<img src="https://item.kakaocdn.net/do/{prefix}{"e" * 32}-g?_v=_R_4x_-0-0">'
        f'</body></html>'
    )
    found = KakaoEmoticonParser().extract(page, "https://e.kakao.com/t/x")
    # dup은 1개로 합쳐져서 총 4개(고유 이미지)
    assert len(found) == 4


def test_kakao_parser_single_image_page_falls_back():
    # 팩을 못 이루는(MIN_PACK 미만) 경우엔 찾은 것 전부 반환
    page = (
        '<html><body>'
        '<img src="https://item.kakaocdn.net/do/'
        + "1" * 64 + '-g?_v=_R_1x_-0-0"></body></html>'
    )
    found = KakaoEmoticonParser().extract(page, "https://e.kakao.com/t/x")
    assert len(found) == 1



def test_generic_parser_absolutizes_and_filters():
    page = """
    <html><body>
      <img src="/img/a.png">
      <img data-src="https://cdn.example.com/b.webp">
      <img src="/script.js">
      <img src="data:image/png;base64,AAAA">
    </body></html>
    """
    urls = [c.url for c in GenericImageParser().extract(page, "https://site.test/page")]
    assert "https://site.test/img/a.png" in urls
    assert "https://cdn.example.com/b.webp" in urls
    assert not any(u.endswith(".js") for u in urls)
    assert not any(u.startswith("data:") for u in urls)
