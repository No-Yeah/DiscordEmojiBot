"""URL 입력 -> 추출 -> 다운로드 -> 변환 -> 저장 -> 등록 전체 경로 검증.

로컬 HTTP 서버를 띄우므로 이 테스트에서만 사설망 접근을 허용한다.
"""

from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from app.config import settings
from app.emoticon import service as emoticon_service
from app.emotion.service import seed_emotions
from app.storage.local import get_storage
from tests.conftest import make_png

PAGE = b"""<html><head><title>test pack</title></head><body>
<img src="/img/one.png"><img src="/img/two.png"></body></html>"""

# 정상 이미지 1개 + 위장 파일 1개 (일부 실패 시 나머지 등록 유지 검증용)
PAGE2 = b"""<html><body>
<img src="/img/solo.png"><img src="/evil.png"></body></html>"""


def _distinct_png() -> bytes:
    from PIL import Image, ImageDraw

    im = Image.new("RGBA", (160, 120), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse([20, 10, 130, 110], fill=(30, 144, 255, 255))
    import io as _io

    buf = _io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        if self.path == "/img/solo.png":
            body = _distinct_png()
            ctype = "image/png"
        elif self.path.startswith("/img/"):
            body = make_png()
            ctype = "image/png"
        elif self.path == "/evil.png":
            body = b"<html><script>alert(1)</script></html>"
            ctype = "image/png"  # Content-Type 위조
        elif self.path == "/pack2":
            body = PAGE2
            ctype = "text/html; charset=utf-8"
        else:
            body = PAGE
            ctype = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):  # 테스트 출력 조용히
        return


@pytest.fixture
def http_server(monkeypatch):
    monkeypatch.setattr(settings, "allow_private_network", True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()


async def test_full_registration_flow(session, http_server):
    await seed_emotions(session)

    extracted = await emoticon_service.extract_candidates(f"{http_server}/pack")
    assert extracted.parser == "generic"
    assert len(extracted.candidates) == 2

    emoticon = await emoticon_service.register(
        session,
        name="누룽이 아무튼",
        image_url=extracted.candidates[0].url,
        source_url=extracted.source_url,
        keywords=["아무튼", "누룽이"],
        emotions=["#황당", "체념"],
    )

    assert emoticon.name == "누룽이_아무튼"  # 공백은 안전하게 치환
    assert emoticon.width == emoticon.height == settings.image_size
    assert {e.tag for e in emoticon.emotions} == {"황당", "체념"}
    assert {k.value for k in emoticon.keywords} == {"아무튼", "누룽이"}

    storage = get_storage()
    assert storage.exists(emoticon.processed_path)
    assert storage.exists(emoticon.preview_path)
    assert storage.exists(emoticon.original_path)


async def test_same_image_from_different_url_is_rejected(session, http_server):
    await emoticon_service.register(
        session, name="첫번째", image_url=f"{http_server}/img/one.png", keep_original=False
    )
    with pytest.raises(emoticon_service.DuplicateEmoticon):
        await emoticon_service.register(
            session,
            name="두번째",
            image_url=f"{http_server}/img/two.png",  # URL은 다르지만 같은 이미지
            keep_original=False,
        )


async def test_fake_image_is_rejected(session, http_server):
    with pytest.raises(emoticon_service.RegistrationError):
        await emoticon_service.register(
            session, name="가짜", image_url=f"{http_server}/evil.png", keep_original=False
        )


async def test_storage_blocks_path_traversal():
    storage = get_storage()
    with pytest.raises(ValueError):
        storage.save("../../etc/passwd", b"x")


async def test_register_pack_adds_all_distinct_without_emotions(session, http_server):
    from app.emotion.service import seed_emotions

    await seed_emotions(session)
    result = await emoticon_service.register_pack(
        session,
        url=f"{http_server}/pack",
        base_name="누룽이팩",
        keywords=["누룽이"],
        keep_original=False,
    )
    # one.png, two.png 는 바이트가 완전히 동일하므로(sha256 일치) 하나만 등록된다.
    # 팩 등록은 dHash 유사도 검사를 끄므로, '비슷하지만 다른' 이미지는 병합되지 않는다.
    assert result.total == 2
    assert len(result.added) == 1
    assert len(result.skipped) == 1
    assert not result.failed

    added = result.added[0]
    assert added.name == "누룽이팩_1"
    assert added.status == "added"

    from app.emoticon import repository as repo

    rows = await repo.list_all(session, limit=50)
    assert [e.name for e in rows] == ["누룽이팩_1"]
    # 팩 등록은 감정을 달지 않는다(이후 태깅 페이지에서 개별로)
    assert rows[0].emotions == []
    assert [k.value for k in rows[0].keywords] == ["누룽이"]


async def test_register_pack_one_failure_does_not_abort_others(session, http_server):
    # /pack2 는 정상 이미지 1개 + 위장 파일 1개를 준다(픽스처에서 제공)
    result = await emoticon_service.register_pack(
        session, url=f"{http_server}/pack2", base_name="혼합", keep_original=False
    )
    assert len(result.added) == 1
    assert len(result.failed) == 1
    # 실패가 있어도 정상 항목은 커밋되어야 한다
    from app.emoticon import repository as repo

    rows = await repo.list_all(session, limit=50)
    assert len(rows) == 1


async def test_register_pack_keeps_visually_similar_distinct_frames(session, monkeypatch):
    """팩 안의 '비슷하지만 다른' 프레임이 dHash 오탐으로 병합되지 않아야 한다."""
    from app.crawler.base import ImageCandidate
    from app.image.processor import ProcessedImage
    from tests.conftest import make_png

    async def fake_extract(_url):
        return emoticon_service.ExtractResult(
            source_url="https://pack.example/p",
            parser="generic",
            candidates=[ImageCandidate(url=f"https://pack.example/{i}.png") for i in range(3)],
        )

    # 세 프레임: 바이트는 다르지만(sha 다름) dHash는 모두 동일하게 강제한다.
    counter = {"n": 0}

    async def fake_download(_url, **_kw):
        counter["n"] += 1
        return ProcessedImage(
            png=make_png(color=(counter["n"] * 40, 0, 0, 255)),
            emoji_png=make_png(),
            width=512, height=512,
            sha256=f"{counter['n']:064d}",       # 프레임마다 다름
            dhash="ffffffffffffffff",             # 전부 동일(최악의 오탐 상황)
            source_format="PNG",
        )

    monkeypatch.setattr(emoticon_service, "extract_candidates", fake_extract)
    monkeypatch.setattr(emoticon_service, "download_and_process", fake_download)

    result = await emoticon_service.register_pack(
        session, url="https://pack.example/p", base_name="포즈", keep_original=False
    )
    # dHash가 모두 같아도 세 개 전부 등록되어야 한다
    assert len(result.added) == 3
    assert not result.skipped
    assert [r.name for r in result.added] == ["포즈_1", "포즈_2", "포즈_3"]
