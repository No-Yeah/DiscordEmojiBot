"""팩(묶음) 등록/조회/삭제 + 태깅 서버 데이터 로직 테스트."""

from __future__ import annotations

import io
from unittest.mock import patch

import pytest
from PIL import Image, ImageDraw

from app.crawler.base import ImageCandidate
from app.emoticon import repository as repo
from app.emoticon import service as svc
from app.emotion.service import seed_emotions

pytestmark = pytest.mark.asyncio


def _shape(kind: str) -> bytes:
    im = Image.new("RGBA", (120, 100), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if kind == "a":
        d.ellipse([10, 10, 110, 90], fill=(255, 0, 0, 255))
    elif kind == "b":
        d.rectangle([10, 20, 110, 80], fill=(0, 255, 0, 255))
    else:
        d.polygon([(60, 5), (10, 95), (110, 95)], fill=(0, 0, 255, 255))
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


def _patched():
    imgs = {f"https://x/{k}.png": _shape(k) for k in "abc"}

    async def fake_extract(url):
        return svc.ExtractResult(
            source_url="https://x/pack", parser="test",
            candidates=[ImageCandidate(url=u) for u in imgs],
        )

    from app.image.processor import process

    async def fake_dl(url, **kw):
        return process(imgs[url])

    return patch.object(svc, "extract_candidates", fake_extract), \
        patch.object(svc, "download_and_process", fake_dl)


async def test_register_pack_creates_pack_and_links(session):
    await seed_emotions(session)
    p1, p2 = _patched()
    with p1, p2:
        result = await svc.register_pack(
            session, url="https://x/pack", base_name="마루", keep_original=False
        )
    assert result.pack_id is not None
    assert result.pack_name == "마루"
    assert len(result.added) == 3

    members = await repo.pack_members(session, result.pack_id)
    assert [e.name for e in members] == ["마루_1", "마루_2", "마루_3"]
    assert all(e.pack_id == result.pack_id for e in members)


async def test_pack_counts_and_status(session):
    await seed_emotions(session)
    p1, p2 = _patched()
    with p1, p2:
        result = await svc.register_pack(
            session, url="https://x/pack", base_name="팩A", keep_original=False
        )
    counts = await repo.pack_counts(session)
    assert counts[result.pack_id] == 3

    packs = await repo.list_packs(session)
    assert len(packs) == 1 and packs[0].name == "팩A"


async def test_delete_pack_removes_all_members(session):
    await seed_emotions(session)
    p1, p2 = _patched()
    with p1, p2:
        result = await svc.register_pack(
            session, url="https://x/pack", base_name="지울팩", keep_original=False
        )
    pack = await repo.get_pack(session, result.pack_id)
    n = await svc.delete_pack(session, pack)
    assert n == 3
    assert await repo.count(session) == 0
    assert await repo.list_packs(session) == []


async def test_empty_pack_is_cleaned_up(session, monkeypatch):
    await seed_emotions(session)

    async def fake_extract(url):
        return svc.ExtractResult(source_url="https://x/p", parser="t", candidates=[])

    monkeypatch.setattr(svc, "extract_candidates", fake_extract)
    result = await svc.register_pack(
        session, url="https://x/p", base_name="빈팩", keep_original=False
    )
    # 후보가 없으면 팩도 안 남는다
    assert result.pack_id is None
    assert await repo.list_packs(session) == []


# ── 태깅 서버 데이터 로직(동기) ──
@pytest.mark.filterwarnings("ignore")
def test_tagging_emotion_crud(tmp_path):
    """태깅 서버의 감정 생성/이름변경/삭제 로직을 동기 세션으로 검증."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base, Emotion
    import app.tagging.server as ts

    engine = create_engine(f"sqlite:///{tmp_path}/t.db")
    Base.metadata.create_all(engine)
    Session = sessionmaker(engine)

    with Session() as s:
        # 생성
        e = ts._create_emotion(s, "뿌듯")
        assert e is not None and e.tag == "뿌듯" and e.icon == ""
        # 중복 생성 방지
        assert ts._create_emotion(s, "뿌듯") is None
        # 이름 변경
        r = ts._rename_emotion(s, "뿌듯", "흐뭇")
        assert r is not None and r.tag == "흐뭇"
        # 삭제
        assert ts._delete_emotion(s, "흐뭇") is True
        assert ts._delete_emotion(s, "없음") is False
        assert s.query(Emotion).count() == 0
    engine.dispose()
