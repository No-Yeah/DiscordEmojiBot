from __future__ import annotations

import io

import pytest
from PIL import Image

from app.image.processor import hamming_distance, process
from app.image.validator import ImageValidationError, validate
from tests.conftest import make_png


def test_process_makes_square_transparent_png():
    result = process(make_png((200, 120)), size=256)
    assert result.width == result.height == 256
    with Image.open(io.BytesIO(result.png)) as im:
        assert im.format == "PNG"
        assert im.mode == "RGBA"
        # 여백은 투명으로 채워져야 한다
        assert im.getpixel((0, 0))[3] == 0


def test_process_keeps_aspect_ratio():
    # 가로로 살짝 긴 이미지가 세로로 늘어나면 안 된다.
    # (스프라이트로 오인되지 않는 완만한 5:4 비율을 쓴다)
    wide = Image.new("RGBA", (250, 200), (0, 0, 255, 255))
    buf = io.BytesIO()
    wide.save(buf, format="PNG")
    result = process(buf.getvalue(), size=256)
    with Image.open(io.BytesIO(result.png)) as im:
        opaque_rows = [y for y in range(im.height) if im.getpixel((im.width // 2, y))[3] > 0]
    height = max(opaque_rows) - min(opaque_rows) + 1
    # 250:200 → 256폭 기준 세로 약 205 (정사각으로 안 늘어남)
    assert 190 <= height <= 215


def test_emoji_variant_fits_discord_limit():
    result = process(make_png((1024, 1024)))
    assert len(result.emoji_png) <= 256 * 1024


def test_identical_images_share_hashes():
    a = process(make_png())
    b = process(make_png())
    assert a.sha256 == b.sha256
    assert a.dhash == b.dhash


def test_different_images_differ_visually():
    a = process(make_png(color=(255, 0, 0, 255)))
    b = process(make_png((200, 120), color=(0, 255, 0, 255)))
    # 색만 다르면 dhash는 비슷할 수 있으니 구조가 다른 케이스로 검증
    c = process(make_png((300, 300)))
    assert a.sha256 != b.sha256
    assert hamming_distance(a.dhash, c.dhash) > 0


def test_validate_rejects_html_disguised_as_image():
    with pytest.raises(ImageValidationError):
        validate(b"<!DOCTYPE html><html><script>alert(1)</script></html>")


def test_validate_rejects_garbage():
    with pytest.raises(ImageValidationError):
        validate(b"\x00\x01\x02not an image at all")


def test_validate_accepts_png():
    assert validate(make_png()) == "PNG"


def _vertical_strip(frames=4, cell=120):
    """세로로 이어붙인 스프라이트(움직이는 이모티콘 흉내). 첫 칸=빨강."""
    from PIL import Image, ImageDraw
    im = Image.new("RGBA", (cell, cell * frames), (0, 0, 0, 0))
    draw = ImageDraw.Draw(im)
    colors = [(255, 0, 0, 255), (0, 255, 0, 255), (0, 0, 255, 255), (255, 255, 0, 255)]
    for i in range(frames):
        draw.ellipse([10, i * cell + 10, cell - 10, i * cell + cell - 10], fill=colors[i % 4])
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


def test_vertical_sprite_strip_uses_first_frame():
    result = process(_vertical_strip(4), size=256)
    assert result.width == result.height == 256
    with Image.open(io.BytesIO(result.png)) as im:
        px = im.convert("RGBA").getpixel((im.width // 2, im.height // 2))
    # 첫 프레임(빨강)만 남아야 한다. 전체 스트립이 축소됐다면 중앙은 빨강이 아니다.
    assert px[0] > 150 and px[1] < 100, f"첫 프레임 추출 실패: {px}"


def test_horizontal_sprite_strip_becomes_square():
    from PIL import Image as _I, ImageDraw
    cell, frames = 100, 3
    im = _I.new("RGBA", (cell * frames, cell), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for i in range(frames):
        d.rectangle([i * cell + 10, 10, i * cell + cell - 10, cell - 10], fill=(50, 100, 200, 255))
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    result = process(buf.getvalue(), size=256)
    assert result.width == result.height == 256


def test_square_emoticon_not_treated_as_sprite():
    # 정사각(정지) 이모티콘은 스프라이트 crop 대상이 아니어야 한다
    result = process(make_png((200, 200), color=(120, 80, 255, 255)), size=256)
    with Image.open(io.BytesIO(result.png)) as im:
        opaque = [
            y for y in range(im.height)
            if im.convert("RGBA").getpixel((im.width // 2, y))[3] > 0
        ]
    # 세로로 잘렸다면 불투명 영역이 위쪽 1/4에만 몰린다. 전체에 퍼져 있어야 정상.
    assert max(opaque) - min(opaque) > im.height * 0.3
