"""설정 파싱: 선택 정수 필드의 빈 값 처리."""

from __future__ import annotations

import pytest

from app.config import Settings


@pytest.mark.parametrize("raw", ["", "   ", None])
def test_blank_dev_guild_id_becomes_none(raw):
    kwargs = {"discord_bot_token": "x"}
    if raw is not None:
        kwargs["discord_dev_guild_id"] = raw
    settings = Settings(**kwargs)
    assert settings.discord_dev_guild_id is None


def test_real_dev_guild_id_parsed():
    settings = Settings(discord_bot_token="x", discord_dev_guild_id="123456789012345678")
    assert settings.discord_dev_guild_id == 123456789012345678
