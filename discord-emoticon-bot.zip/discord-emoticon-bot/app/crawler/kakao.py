"""e.kakao.com 이모티콘 상세 페이지 파서.

카카오 이모티콘 이미지 URL은 확장자 없이 다음 형태로 주어진다.
    https://item.kakaocdn.net/do/<64자리 hex>-g?_v=...
    https://item.kakaocdn.net/do/<64자리 hex>            (일부)

한 팩의 개별 이모티콘들은 앞부분 해시(약 32자)가 서로 같다.
    d67387137ba0ea78d04c1427aba7bf10  <- 공통 prefix
그 뒤 32자가 이모티콘별로 달라진다. 이 성질을 이용해, 페이지에 섞여 있는
관련상품/작가/추천 썸네일(prefix가 제각각)에서 '본품 묶음'만 골라낸다.

구조가 바뀌면 이 파일만 고치면 된다.

주의: 카카오 이모티콘은 저작권이 있는 콘텐츠다. 개인적인 사용 범위를 넘어
재배포/공유하지 않도록 한다.
"""

from __future__ import annotations

import html
import logging
import re
from collections import Counter

from app.crawler.base import ImageCandidate, host_of

logger = logging.getLogger(__name__)

# item.kakaocdn.net/do/<64 hex>[ -g ][ ?_v=... ]  (확장자 없음이 기본)
ITEM_RE = re.compile(
    r"https?://item\.kakaocdn\.net/do/([0-9a-fA-F]{64})(-g)?(\?_v=[^\s\"'\\<>)]*)?",
    re.IGNORECASE,
)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)

# 팩 하나의 개별 이모티콘은 앞 PREFIX_LEN 자가 동일하다.
PREFIX_LEN = 32
# 관련상품/추천에도 같은 prefix 몇 개가 우연히 낄 수 있으므로, 본품으로 인정하는
# 최소 개수. 보통 한 팩은 16~32개다.
MIN_PACK = 4


def _iter_urls(page: str) -> list[tuple[str, str]]:
    """(정규화된 URL, 64자 해시) 목록을 등장 순서대로 반환(중복 제거)."""
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    for m in ITEM_RE.finditer(page):
        digest = m.group(1).lower()
        url = html.unescape(m.group(0))
        key = digest  # 같은 이미지의 다른 쿼리스트링을 하나로 취급
        if key in seen:
            continue
        seen.add(key)
        out.append((url, digest))
    return out


class KakaoEmoticonParser:
    name = "kakao"

    def matches(self, url: str) -> bool:
        host = host_of(url)
        return host.endswith("kakao.com") or host.endswith("kakaocdn.net")

    def extract(self, page: str, base_url: str) -> list[ImageCandidate]:
        title = None
        if m := TITLE_RE.search(page):
            title = html.unescape(m.group(1)).strip() or None

        urls = _iter_urls(page)
        if not urls:
            logger.info("kakao: item.kakaocdn 이미지를 찾지 못함 (%s)", base_url)
            return []

        # prefix(앞 32자)별로 묶어 가장 많이 등장한 그룹을 본품으로 본다.
        groups: dict[str, list[str]] = {}
        for url, digest in urls:
            groups.setdefault(digest[:PREFIX_LEN], []).append(url)

        prefix, members = max(groups.items(), key=lambda kv: len(kv[1]))

        if len(members) >= MIN_PACK:
            logger.info(
                "kakao: 본품 %d개 선택 (prefix=%s, 전체 후보 %d)",
                len(members), prefix, len(urls),
            )
            return [ImageCandidate(url=u, title=title) for u in members]

        # 팩을 특정하지 못하면(단일 이미지 페이지 등) 찾은 것 전부를 후보로 준다.
        logger.info("kakao: 팩 그룹을 못 정해 전체 %d개 반환", len(urls))
        return [ImageCandidate(url=u, title=title) for u, _ in urls]
