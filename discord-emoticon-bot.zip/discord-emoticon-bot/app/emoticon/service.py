"""이모티콘 등록/수정/삭제 비즈니스 로직.

URL 입력 -> 페이지 분석 -> 이미지 추출 -> 다운로드 -> 검증 -> PNG 정규화
-> 중복 검사 -> 저장 -> 메타데이터 등록
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.crawler.base import ImageCandidate, get_parser, host_of
from app.crawler.fetcher import FetchError, fetch
from app.db.models import Emoticon, Pack
from app.emoticon import repository as repo
from app.emotion import service as emotion_service
from app.image.processor import ProcessedImage, process
from app.image.validator import ImageValidationError
from app.storage.local import get_storage

logger = logging.getLogger(__name__)

_SAFE_NAME_RE = re.compile(r"[^\w가-힣ㄱ-ㅎㅏ-ㅣ._-]+")


class RegistrationError(RuntimeError):
    pass


class DuplicateEmoticon(RegistrationError):
    def __init__(self, existing: Emoticon) -> None:
        super().__init__(f"이미 등록된 이모티콘입니다: {existing.name} (#{existing.id})")
        self.existing = existing


@dataclass(frozen=True, slots=True)
class ExtractResult:
    source_url: str
    parser: str
    candidates: list[ImageCandidate]


@dataclass(slots=True)
class PackItemResult:
    index: int
    status: str            # "added" | "duplicate" | "error"
    name: str | None = None
    emoticon_id: int | None = None
    detail: str | None = None


@dataclass(slots=True)
class PackResult:
    source_url: str
    parser: str
    total: int
    added: list[PackItemResult]
    skipped: list[PackItemResult]
    failed: list[PackItemResult]
    pack_id: int | None = None
    pack_name: str | None = None

    @property
    def summary(self) -> str:
        return (
            f"총 {self.total}개 중 등록 {len(self.added)} · "
            f"중복 {len(self.skipped)} · 실패 {len(self.failed)}"
        )


def normalize_name(raw: str) -> str:
    name = _SAFE_NAME_RE.sub("_", raw.strip()).strip("_")
    return (name or "emoticon")[:100]


async def extract_candidates(url: str) -> ExtractResult:
    """URL을 열어 이모티콘 이미지 후보 목록을 만든다."""
    result = await fetch(url)

    if result.is_image:
        return ExtractResult(
            source_url=result.url,
            parser="direct",
            candidates=[ImageCandidate(url=result.url)],
        )

    try:
        page = result.content.decode("utf-8", errors="replace")
    except Exception as exc:  # pragma: no cover - 방어적
        raise RegistrationError(f"페이지를 읽을 수 없습니다: {exc}") from exc

    parser = get_parser(result.url)
    candidates = parser.extract(page, result.url)
    if not candidates:
        raise RegistrationError(
            "이 페이지에서 이모티콘 이미지를 찾지 못했습니다. 이미지 URL을 직접 입력해 보세요."
        )
    logger.info("extracted %d candidates from %s (%s)", len(candidates), result.url, parser.name)
    return ExtractResult(source_url=result.url, parser=parser.name, candidates=candidates)


async def download_and_process(
    image_url: str, *, referer: str | None = None
) -> ProcessedImage:
    try:
        result = await fetch(image_url, referer=referer)
        return process(result.content)
    except (FetchError, ImageValidationError) as exc:
        raise RegistrationError(str(exc)) from exc


async def register(
    session: AsyncSession,
    *,
    name: str,
    image_url: str,
    source_url: str | None = None,
    keywords: list[str] | None = None,
    emotions: list[str] | None = None,
    keep_original: bool = True,
    allow_duplicate: bool = False,
    use_dhash: bool = True,
    referer: str | None = None,
    pack_id: int | None = None,
) -> Emoticon:
    """이미지 URL 하나를 이모티콘으로 등록한다."""
    processed = await download_and_process(image_url, referer=referer)

    duplicate = await repo.find_duplicate(
        session,
        source_url=source_url,
        sha256=processed.sha256,
        dhash=processed.dhash,
        use_dhash=use_dhash,
    )
    if duplicate is not None and not allow_duplicate:
        raise DuplicateEmoticon(duplicate)

    base_name = normalize_name(name)
    final_name = base_name
    suffix = 2
    while await repo.get_by_name(session, final_name) is not None:
        final_name = f"{base_name}_{suffix}"
        suffix += 1

    storage = get_storage()
    processed_path = storage.save(
        f"processed/{processed.sha256[:2]}/{processed.sha256}.png", processed.png
    )
    preview_path = storage.save(
        f"preview/{processed.sha256[:2]}/{processed.sha256}.png", processed.emoji_png
    )
    original_path = None
    if keep_original:
        original = await fetch(image_url, referer=referer)
        original_path = storage.save(
            f"original/{processed.sha256[:2]}/{processed.sha256}.bin", original.content
        )

    # 관계 객체를 먼저 확보한 뒤 생성자에 넘긴다.
    # (persistent 객체에 나중에 대입하면 컬렉션 lazy-load가 걸린다)
    keyword_rows = await repo.ensure_keywords(session, keywords or [])
    emotion_rows = await emotion_service.ensure_tags(session, emotions or [])

    emoticon = Emoticon(
        name=final_name,
        source_url=source_url or image_url,
        image_url=image_url,
        source_site=host_of(source_url or image_url),
        pack_id=pack_id,
        original_path=original_path,
        processed_path=processed_path,
        preview_path=preview_path,
        width=processed.width,
        height=processed.height,
        image_sha256=processed.sha256,
        image_dhash=processed.dhash,
        keywords=keyword_rows,
        emotions=emotion_rows,
    )
    await repo.add(session, emoticon)
    logger.info("registered emoticon #%s %s", emoticon.id, emoticon.name)
    return emoticon


async def register_pack(
    session: AsyncSession,
    *,
    url: str,
    base_name: str,
    keywords: list[str] | None = None,
    keep_original: bool = True,
    limit: int | None = None,
) -> PackResult:
    """URL 하나(이모티콘 묶음)에서 찾은 이미지를 감정 없이 한꺼번에 등록한다.

    이름은 `base_name_1`, `base_name_2` … 로 붙는다. 감정은 이후 태깅 웹페이지에서
    이미지를 보며 개별로 단다. 중복(같은 이미지)과 실패는 건너뛰고 결과에 기록한다.
    """
    extracted = await extract_candidates(url)
    candidates = extracted.candidates
    if limit:
        candidates = candidates[:limit]

    base = normalize_name(base_name)

    # 팩 레코드를 먼저 만든다. 하나도 등록 못 해도 빈 팩은 마지막에 정리한다.
    pack = Pack(
        name=base,
        source_url=extracted.source_url,
        source_site=host_of(extracted.source_url),
    )
    session.add(pack)
    await session.flush()

    added: list[PackItemResult] = []
    skipped: list[PackItemResult] = []
    failed: list[PackItemResult] = []

    for i, candidate in enumerate(candidates, start=1):
        item_name = f"{base}_{i}"
        # 각 이미지를 개별 트랜잭션처럼 처리한다.
        # 하나가 실패해도 나머지 등록은 유지되어야 하므로 savepoint를 쓴다.
        try:
            async with session.begin_nested():
                emoticon = await register(
                    session,
                    name=item_name,
                    image_url=candidate.url,
                    source_url=candidate.url,  # 팩은 이미지별 URL을 출처로 둔다
                    keywords=keywords or [],
                    emotions=[],
                    keep_original=keep_original,
                    allow_duplicate=False,
                    # 팩 안에는 비슷한 프레임이 많다. dHash 오탐으로 서로 다른
                    # 이모티콘이 병합되지 않도록, 완전 동일 바이트만 중복 처리한다.
                    use_dhash=False,
                    referer=extracted.source_url,  # 카카오 CDN hotlink 차단 우회
                    pack_id=pack.id,
                )
            added.append(
                PackItemResult(
                    index=i, status="added", name=emoticon.name, emoticon_id=emoticon.id
                )
            )
        except DuplicateEmoticon as exc:
            skipped.append(
                PackItemResult(
                    index=i, status="duplicate",
                    name=exc.existing.name, emoticon_id=exc.existing.id,
                    detail="같은 이미지가 이미 등록됨",
                )
            )
        except (FetchError, RegistrationError, ImageValidationError) as exc:
            failed.append(PackItemResult(index=i, status="error", detail=str(exc)))

    # 하나도 등록 못 했으면 빈 팩 레코드를 지운다.
    if not added:
        await session.delete(pack)
        await session.flush()
        pack_id = None
    else:
        pack_id = pack.id

    result = PackResult(
        source_url=extracted.source_url,
        parser=extracted.parser,
        total=len(candidates),
        added=added,
        skipped=skipped,
        failed=failed,
        pack_id=pack_id,
        pack_name=base,
    )
    logger.info("pack '%s' (id=%s): %s", base, pack_id, result.summary)
    return result


async def update_metadata(
    session: AsyncSession,
    emoticon: Emoticon,
    *,
    name: str | None = None,
    keywords: list[str] | None = None,
    emotions: list[str] | None = None,
) -> Emoticon:
    if name:
        new_name = normalize_name(name)
        existing = await repo.get_by_name(session, new_name)
        if existing is not None and existing.id != emoticon.id:
            raise RegistrationError(f"이미 같은 이름이 있습니다: {new_name}")
        emoticon.name = new_name
    if keywords is not None:
        emoticon.keywords = await repo.ensure_keywords(session, keywords)
    if emotions is not None:
        emoticon.emotions = await emotion_service.ensure_tags(session, emotions)
    await session.flush()
    return emoticon


async def delete(session: AsyncSession, emoticon: Emoticon, *, remove_files: bool = True) -> None:
    storage = get_storage()
    paths = [emoticon.processed_path, emoticon.original_path, emoticon.preview_path]
    await repo.remove(session, emoticon)
    await session.flush()
    if remove_files:
        for path in paths:
            if path:
                storage.delete(path)


async def delete_pack(
    session: AsyncSession, pack: Pack, *, remove_files: bool = True
) -> int:
    """팩과 그 안의 모든 이모티콘을 삭제한다. 삭제한 이모티콘 수를 반환."""
    members = await repo.pack_members(session, pack.id)
    for emoticon in members:
        await delete(session, emoticon, remove_files=remove_files)
    await repo.remove_pack(session, pack)
    await session.flush()
    logger.info("pack #%s '%s' 삭제 (%d개)", pack.id, pack.name, len(members))
    return len(members)
