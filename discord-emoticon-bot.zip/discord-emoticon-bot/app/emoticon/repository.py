"""이모티콘 DB 접근. 비즈니스 로직은 service.py에 둔다."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import (
    Emoticon,
    Emotion,
    Favorite,
    Keyword,
    Pack,
    UsageLog,
    emoticon_emotions,
    emoticon_keywords,
)


async def get(session: AsyncSession, emoticon_id: int) -> Emoticon | None:
    return await session.get(Emoticon, emoticon_id)


async def get_by_name(session: AsyncSession, name: str) -> Emoticon | None:
    return await session.scalar(select(Emoticon).where(Emoticon.name == name))


async def find_duplicate(
    session: AsyncSession,
    *,
    source_url: str | None,
    sha256: str,
    dhash: str,
    use_dhash: bool = True,
) -> Emoticon | None:
    """중복 후보를 찾는다.

    - sha256: 완전히 동일한 바이트(항상 검사)
    - source_url: 같은 출처 URL(항상 검사)
    - dhash: 시각적으로 동일/유사(use_dhash=True일 때만).
      팩 일괄 등록처럼 비슷한 프레임이 많은 경우 dHash 오탐으로 프레임을
      잃을 수 있어, 그때는 use_dhash=False로 끈다.
    """
    conditions = [Emoticon.image_sha256 == sha256]
    if use_dhash:
        conditions.append(Emoticon.image_dhash == dhash)
    if source_url:
        conditions.append(Emoticon.source_url == source_url)
    stmt = select(Emoticon).where(func.coalesce(Emoticon.is_active, True).is_(True))
    for cond in conditions:
        found = await session.scalar(stmt.where(cond).limit(1))
        if found is not None:
            return found
    return None


async def add(session: AsyncSession, emoticon: Emoticon) -> Emoticon:
    session.add(emoticon)
    await session.flush()
    return emoticon


async def remove(session: AsyncSession, emoticon: Emoticon) -> None:
    await session.delete(emoticon)


async def list_all(
    session: AsyncSession, *, query: str | None = None, limit: int = 100, offset: int = 0
) -> list[Emoticon]:
    stmt = select(Emoticon).where(Emoticon.is_active.is_(True))
    if query:
        stmt = stmt.where(Emoticon.name.ilike(f"%{query}%"))
    stmt = stmt.order_by(Emoticon.created_at.desc()).limit(limit).offset(offset)
    return list((await session.scalars(stmt)).all())


async def count(session: AsyncSession) -> int:
    return int(await session.scalar(select(func.count(Emoticon.id))) or 0)


async def ensure_keywords(session: AsyncSession, values: list[str]) -> list[Keyword]:
    out: list[Keyword] = []
    for raw in values:
        value = raw.strip().lstrip("#").strip()
        if not value:
            continue
        keyword = await session.scalar(select(Keyword).where(Keyword.value == value))
        if keyword is None:
            keyword = Keyword(value=value)
            session.add(keyword)
            await session.flush()
        if keyword not in out:
            out.append(keyword)
    return out


async def search_candidates(
    session: AsyncSession, *, text: str | None, tags: list[str], limit: int
) -> list[Emoticon]:
    """이름/키워드/감정 중 하나라도 걸리는 후보를 넉넉히 가져온다.

    ponytail: 개인용(수천 건) 규모라 후보를 가져와 파이썬에서 점수를 매긴다.
    수만 건을 넘어가면 FTS5(SQLite) 또는 PostgreSQL tsvector로 올린다.
    """
    stmt = select(Emoticon).where(Emoticon.is_active.is_(True))
    conditions = []

    if text:
        pattern = f"%{text}%"
        conditions.append(Emoticon.name.ilike(pattern))
        conditions.append(
            Emoticon.id.in_(
                select(emoticon_keywords.c.emoticon_id)
                .join(Keyword, Keyword.id == emoticon_keywords.c.keyword_id)
                .where(Keyword.value.ilike(pattern))
            )
        )
        conditions.append(
            Emoticon.id.in_(
                select(emoticon_emotions.c.emoticon_id)
                .join(Emotion, Emotion.id == emoticon_emotions.c.emotion_id)
                .where(Emotion.tag.ilike(pattern))
            )
        )
    if tags:
        conditions.append(
            Emoticon.id.in_(
                select(emoticon_emotions.c.emoticon_id)
                .join(Emotion, Emotion.id == emoticon_emotions.c.emotion_id)
                .where(Emotion.tag.in_(tags))
            )
        )

    if conditions:
        from sqlalchemy import or_

        stmt = stmt.where(or_(*conditions))
    stmt = stmt.limit(limit)
    return list((await session.scalars(stmt)).all())


async def recent_for_user(
    session: AsyncSession, user_id: int, limit: int = 8
) -> list[Emoticon]:
    sub = (
        select(UsageLog.emoticon_id, func.max(UsageLog.used_at).label("last_used"))
        .where(UsageLog.user_id == user_id)
        .group_by(UsageLog.emoticon_id)
        .subquery()
    )
    stmt = (
        select(Emoticon)
        .join(sub, sub.c.emoticon_id == Emoticon.id)
        .where(Emoticon.is_active.is_(True))
        .order_by(sub.c.last_used.desc())
        .limit(limit)
    )
    return list((await session.scalars(stmt)).all())


async def favorites_for_user(
    session: AsyncSession, user_id: int, limit: int = 8
) -> list[Emoticon]:
    stmt = (
        select(Emoticon)
        .join(Favorite, Favorite.emoticon_id == Emoticon.id)
        .where(Favorite.user_id == user_id, Emoticon.is_active.is_(True))
        .order_by(Favorite.created_at.desc())
        .limit(limit)
    )
    return list((await session.scalars(stmt)).all())


async def toggle_favorite(session: AsyncSession, user_id: int, emoticon_id: int) -> bool:
    """즐겨찾기 상태를 뒤집고, 최종 상태(True=등록됨)를 반환."""
    existing = await session.scalar(
        select(Favorite).where(
            Favorite.user_id == user_id, Favorite.emoticon_id == emoticon_id
        )
    )
    if existing is not None:
        await session.delete(existing)
        return False
    session.add(Favorite(user_id=user_id, emoticon_id=emoticon_id))
    return True


async def log_usage(
    session: AsyncSession,
    *,
    emoticon_id: int,
    user_id: int,
    guild_id: int | None,
    context: str,
) -> None:
    session.add(
        UsageLog(
            emoticon_id=emoticon_id, user_id=user_id, guild_id=guild_id, context=context
        )
    )


async def usage_scores(
    session: AsyncSession, user_id: int, days: int = 30
) -> dict[int, int]:
    """최근 N일 사용 횟수(정렬 보너스용)."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    rows = await session.execute(
        select(UsageLog.emoticon_id, func.count(UsageLog.id))
        .where(UsageLog.user_id == user_id, UsageLog.used_at >= since)
        .group_by(UsageLog.emoticon_id)
    )
    return {int(eid): int(cnt) for eid, cnt in rows}


async def purge_usage(session: AsyncSession, emoticon_id: int) -> None:
    await session.execute(delete(UsageLog).where(UsageLog.emoticon_id == emoticon_id))


# ── 팩(묶음) ─────────────────────────────────────────────────
async def get_pack(session: AsyncSession, pack_id: int) -> Pack | None:
    return await session.get(Pack, pack_id)


async def list_packs(session: AsyncSession, *, query: str | None = None) -> list[Pack]:
    stmt = select(Pack)
    if query:
        stmt = stmt.where(Pack.name.ilike(f"%{query}%"))
    stmt = stmt.order_by(Pack.created_at.desc())
    return list((await session.scalars(stmt)).all())


async def pack_members(session: AsyncSession, pack_id: int) -> list[Emoticon]:
    stmt = (
        select(Emoticon)
        .where(Emoticon.pack_id == pack_id, Emoticon.is_active.is_(True))
        .order_by(Emoticon.name)
    )
    return list((await session.scalars(stmt)).all())


async def pack_counts(session: AsyncSession) -> dict[int, int]:
    """팩별 이모티콘 개수."""
    rows = await session.execute(
        select(Emoticon.pack_id, func.count(Emoticon.id))
        .where(Emoticon.pack_id.isnot(None), Emoticon.is_active.is_(True))
        .group_by(Emoticon.pack_id)
    )
    return {int(pid): int(cnt) for pid, cnt in rows}


async def pack_tag_summary(session: AsyncSession, pack_id: int) -> dict[str, int]:
    """팩 안에서 각 감정 태그가 몇 개 이모티콘에 달렸는지."""
    rows = await session.execute(
        select(Emotion.tag, func.count(emoticon_emotions.c.emoticon_id))
        .join(emoticon_emotions, emoticon_emotions.c.emotion_id == Emotion.id)
        .join(Emoticon, Emoticon.id == emoticon_emotions.c.emoticon_id)
        .where(Emoticon.pack_id == pack_id)
        .group_by(Emotion.tag)
        .order_by(func.count(emoticon_emotions.c.emoticon_id).desc())
    )
    return {tag: int(cnt) for tag, cnt in rows}


async def remove_pack(session: AsyncSession, pack: Pack) -> None:
    await session.delete(pack)
