"""로컬 감정 태깅 웹페이지.

CLI로는 이미지를 볼 수 없어서, 등록된 이모티콘을 썸네일 격자로 띄우고
클릭으로 감정을 다는 로컬 전용 페이지다. 표준 라이브러리(http.server)만 쓴다.

실행:
    python -m app.tagging.server            # http://127.0.0.1:8000
    python -m app.tagging.server --port 9000

주의: 인증이 없다. localhost(127.0.0.1)에만 바인딩하는 개인용 도구다.
데이터를 수정하므로 외부에 열지 말 것(--host 0.0.0.0 사용 금지).
"""

from __future__ import annotations

import argparse
import json
import logging
import mimetypes
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.db.models import Emoticon, Emotion
from app.emotion.tags import normalize_tag
from app.main import setup_logging
from app.storage.local import get_storage

logger = logging.getLogger(__name__)

# 봇(async)과 같은 SQLite 파일을 sync 드라이버로 연다. WAL이라 동시 접근이 가능하다.
_engine = create_engine(
    settings.sync_url,
    future=True,
    connect_args={"timeout": 15} if settings.sync_url.startswith("sqlite") else {},
)

if settings.sync_url.startswith("sqlite"):

    @event.listens_for(_engine, "connect")
    def _sqlite_pragma(dbapi_conn, _record):  # pragma: no cover - 드라이버 콜백
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA busy_timeout=15000")
        cur.close()


_Session = sessionmaker(_engine, expire_on_commit=False)


# ── 데이터 접근(sync) ─────────────────────────────────────────
def _emotions(session: Session) -> list[Emotion]:
    return list(
        session.scalars(select(Emotion).order_by(Emotion.sort_order, Emotion.tag)).all()
    )


def _emoticons(session: Session) -> list[Emoticon]:
    stmt = select(Emoticon).where(Emoticon.is_active.is_(True)).order_by(
        Emoticon.created_at.desc()
    )
    return list(session.scalars(stmt).all())


def _set_emotions(session: Session, emoticon_id: int, tags: list[str]) -> Emoticon | None:
    emoticon = session.get(Emoticon, emoticon_id)
    if emoticon is None:
        return None
    rows: list[Emotion] = []
    for raw in tags:
        tag = normalize_tag(raw)
        if not tag:
            continue
        emotion = session.scalar(select(Emotion).where(Emotion.tag == tag))
        if emotion is None:
            emotion = Emotion(tag=tag, label=tag, icon="🏷️", sort_order=500)
            session.add(emotion)
            session.flush()
        if emotion not in rows:
            rows.append(emotion)
    emoticon.emotions = rows
    session.commit()
    return emoticon


def _emoticon_dict(emoticon: Emoticon) -> dict:
    return {
        "id": emoticon.id,
        "name": emoticon.name,
        "emotions": sorted(e.tag for e in emoticon.emotions),
        "keywords": sorted(k.value for k in emoticon.keywords),
        "image": f"/image/{emoticon.id}",
    }


# ── HTTP 핸들러 ──────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    server_version = "EmoticonTagger/1.0"

    def _send(self, code: int, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code: int, payload: object) -> None:
        self._send(code, json.dumps(payload, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def _error(self, code: int, message: str) -> None:
        self._json(code, {"error": message})

    # -- GET --
    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            if path == "/":
                self._send(HTTPStatus.OK, INDEX_HTML.encode(), "text/html; charset=utf-8")
            elif path == "/api/emotions":
                with _Session() as session:
                    payload = [
                        {"tag": e.tag, "label": e.label, "icon": e.icon}
                        for e in _emotions(session)
                    ]
                self._json(HTTPStatus.OK, payload)
            elif path == "/api/emoticons":
                with _Session() as session:
                    payload = [_emoticon_dict(e) for e in _emoticons(session)]
                self._json(HTTPStatus.OK, payload)
            elif path.startswith("/image/"):
                self._serve_image(path.removeprefix("/image/"))
            else:
                self._error(HTTPStatus.NOT_FOUND, "not found")
        except Exception:  # pragma: no cover - 방어적
            logger.exception("GET %s 실패", path)
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal error")

    def _serve_image(self, raw_id: str) -> None:
        if not raw_id.isdigit():
            self._error(HTTPStatus.BAD_REQUEST, "bad id")
            return
        with _Session() as session:
            emoticon = session.get(Emoticon, int(raw_id))
            rel = emoticon.preview_path or emoticon.processed_path if emoticon else None
        if not rel:
            self._error(HTTPStatus.NOT_FOUND, "no image")
            return
        try:
            data = get_storage().read(rel)
        except (OSError, ValueError):
            self._error(HTTPStatus.NOT_FOUND, "file missing")
            return
        ctype = mimetypes.guess_type(rel)[0] or "image/png"
        self._send(HTTPStatus.OK, data, ctype)

    # -- POST --
    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        parts = path.strip("/").split("/")
        # /api/emoticons/<id>/emotions
        if len(parts) == 4 and parts[:2] == ["api", "emoticons"] and parts[3] == "emotions":
            self._update_emotions(parts[2])
            return
        self._error(HTTPStatus.NOT_FOUND, "not found")

    def _update_emotions(self, raw_id: str) -> None:
        if not raw_id.isdigit():
            self._error(HTTPStatus.BAD_REQUEST, "bad id")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length) or b"{}")
            tags = body.get("emotions", [])
            if not isinstance(tags, list):
                raise ValueError("emotions must be a list")
        except (ValueError, json.JSONDecodeError) as exc:
            self._error(HTTPStatus.BAD_REQUEST, f"bad body: {exc}")
            return

        with _Session() as session:
            emoticon = _set_emotions(session, int(raw_id), [str(t) for t in tags])
            if emoticon is None:
                self._error(HTTPStatus.NOT_FOUND, "emoticon not found")
                return
            payload = _emoticon_dict(emoticon)
        logger.info("tagged #%s -> %s", raw_id, payload["emotions"])
        self._json(HTTPStatus.OK, payload)

    def log_message(self, fmt: str, *args) -> None:  # 요청 로그를 조용히
        logger.debug("%s - %s", self.address_string(), fmt % args)


INDEX_HTML = r"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>이모티콘 감정 태깅</title>
<style>
  :root {
    --bg: #14151a; --panel: #1d1f27; --panel-2: #262933;
    --line: #33363f; --text: #e7e9ee; --muted: #9aa0ac;
    --accent: #7aa2ff; --accent-ink: #0b1020; --ok: #4bd07a;
    --chip: #2a2e39; --chip-on: #7aa2ff;
  }
  @media (prefers-color-scheme: light) {
    :root {
      --bg:#f4f5f8; --panel:#fff; --panel-2:#f0f1f5; --line:#dcdfe6;
      --text:#1c1f26; --muted:#6b7280; --accent:#3a63d6; --accent-ink:#fff;
      --ok:#178a4c; --chip:#eceef3; --chip-on:#3a63d6;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font: 15px/1.5 system-ui, -apple-system, "Segoe UI", "Noto Sans KR", sans-serif;
  }
  header {
    position: sticky; top: 0; z-index: 5; background: var(--panel);
    border-bottom: 1px solid var(--line); padding: 14px 20px;
    display: flex; flex-wrap: wrap; gap: 12px; align-items: center;
  }
  header h1 { font-size: 17px; margin: 0 8px 0 0; font-weight: 650; }
  .count { color: var(--muted); font-size: 13px; }
  .grow { flex: 1; }
  input[type=search], input[type=text] {
    background: var(--panel-2); border: 1px solid var(--line); color: var(--text);
    border-radius: 8px; padding: 8px 11px; font-size: 14px; min-width: 180px;
  }
  input:focus { outline: 2px solid var(--accent); outline-offset: -1px; }
  label.toggle { display: inline-flex; gap: 6px; align-items: center; color: var(--muted); font-size: 14px; cursor: pointer; }
  main { padding: 20px; display: grid; gap: 16px;
    grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); }
  .card {
    background: var(--panel); border: 1px solid var(--line); border-radius: 12px;
    padding: 12px; display: flex; flex-direction: column; gap: 10px; position: relative;
  }
  .thumb {
    align-self: center; width: 128px; height: 128px; border-radius: 8px;
    /* 투명 배경 확인용 체커보드 */
    background-image:
      linear-gradient(45deg, #888 25%, transparent 25%),
      linear-gradient(-45deg, #888 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #888 75%),
      linear-gradient(-45deg, transparent 75%, #888 75%);
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0;
    background-color: #b7b7b7;
  }
  .thumb img { width: 100%; height: 100%; object-fit: contain; }
  .name { font-weight: 600; font-size: 14px; word-break: break-all; }
  .chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chip {
    border: 1px solid var(--line); background: var(--chip); color: var(--text);
    border-radius: 999px; padding: 4px 10px; font-size: 13px; cursor: pointer;
    user-select: none; transition: transform .05s ease;
  }
  .chip:hover { border-color: var(--accent); }
  .chip:active { transform: scale(.96); }
  .chip.on { background: var(--chip-on); color: var(--accent-ink); border-color: var(--chip-on); }
  .saved {
    position: absolute; top: 10px; right: 10px; font-size: 12px; color: var(--ok);
    opacity: 0; transition: opacity .2s ease;
  }
  .saved.show { opacity: 1; }
  .empty { color: var(--muted); grid-column: 1/-1; text-align: center; padding: 60px 0; }
  footer { color: var(--muted); font-size: 12px; padding: 4px 20px 24px; }
</style>
</head>
<body>
<header>
  <h1>이모티콘 감정 태깅</h1>
  <span class="count" id="count">불러오는 중…</span>
  <span class="grow"></span>
  <input type="search" id="q" placeholder="이름 검색">
  <label class="toggle"><input type="checkbox" id="untagged"> 감정 없는 것만</label>
  <input type="text" id="newtag" placeholder="새 감정 추가 후 Enter (예: 뿌듯)">
</header>
<main id="grid"></main>
<footer>칩을 누르면 바로 저장됩니다. 이 페이지는 이 컴퓨터에서만 열립니다.</footer>

<script>
const state = { emotions: [], emoticons: [] };

async function load() {
  const [emo, list] = await Promise.all([
    fetch("/api/emotions").then(r => r.json()),
    fetch("/api/emoticons").then(r => r.json()),
  ]);
  state.emotions = emo;
  state.emoticons = list;
  render();
}

function palette() {
  // 서버 감정 + 아직 저장 전이지만 방금 추가한 커스텀 태그를 합친다
  const map = new Map(state.emotions.map(e => [e.tag, e]));
  for (const it of state.emoticons)
    for (const t of it.emotions)
      if (!map.has(t)) map.set(t, { tag: t, label: t, icon: "🏷️" });
  return [...map.values()];
}

async function save(card, it, tag) {
  const set = new Set(it.emotions);
  set.has(tag) ? set.delete(tag) : set.add(tag);
  const emotions = [...set];
  const res = await fetch(`/api/emoticons/${it.id}/emotions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ emotions }),
  });
  if (!res.ok) { alert("저장 실패"); return; }
  const updated = await res.json();
  it.emotions = updated.emotions;
  drawChips(card, it);
  const flag = card.querySelector(".saved");
  flag.classList.add("show");
  setTimeout(() => flag.classList.remove("show"), 900);
  if (document.getElementById("untagged").checked) render();
}

function drawChips(card, it) {
  const box = card.querySelector(".chips");
  box.innerHTML = "";
  const active = new Set(it.emotions);
  for (const e of palette()) {
    const chip = document.createElement("span");
    chip.className = "chip" + (active.has(e.tag) ? " on" : "");
    chip.textContent = `${e.icon} ${e.label}`;
    chip.onclick = () => save(card, it, e.tag);
    box.appendChild(chip);
  }
}

function render() {
  const grid = document.getElementById("grid");
  const q = document.getElementById("q").value.trim().toLowerCase();
  const onlyUntagged = document.getElementById("untagged").checked;
  grid.innerHTML = "";

  const items = state.emoticons.filter(it => {
    if (onlyUntagged && it.emotions.length) return false;
    if (q && !it.name.toLowerCase().includes(q)
        && !it.keywords.some(k => k.toLowerCase().includes(q))) return false;
    return true;
  });

  document.getElementById("count").textContent =
    `${items.length} / ${state.emoticons.length}개`;

  if (!items.length) {
    grid.innerHTML = '<div class="empty">표시할 이모티콘이 없습니다.</div>';
    return;
  }

  for (const it of items) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML =
      '<span class="saved">저장됨 ✓</span>' +
      `<div class="thumb"><img loading="lazy" src="${it.image}" alt=""></div>` +
      `<div class="name">${it.name}</div>` +
      '<div class="chips"></div>';
    grid.appendChild(card);
    drawChips(card, it);
  }
}

document.getElementById("q").addEventListener("input", render);
document.getElementById("untagged").addEventListener("change", render);
document.getElementById("newtag").addEventListener("keydown", (ev) => {
  if (ev.key !== "Enter") return;
  const tag = ev.target.value.trim().replace(/^#/, "");
  if (!tag) return;
  if (!state.emotions.some(e => e.tag === tag))
    state.emotions.push({ tag, label: tag, icon: "🏷️" });
  ev.target.value = "";
  render();  // 팔레트에 새 칩이 나타난다(클릭하면 그때 저장)
});

load();
</script>
</body>
</html>
"""


def main() -> None:
    # CLI 인자 > 환경변수/.env(settings) > 기본값 순으로 적용한다.
    parser = argparse.ArgumentParser(description="이모티콘 감정 태깅 웹서버")
    parser.add_argument("--host", default=settings.tagging_host)
    parser.add_argument("--port", type=int, default=settings.tagging_port)
    args = parser.parse_args()

    setup_logging()
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        logger.warning(
            "인증이 없는 도구입니다. %s 로 열면 접근 가능한 누구나 DB를 수정할 수 있습니다.",
            args.host,
        )

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    logger.info("감정 태깅 페이지: http://%s:%d  (Ctrl+C 로 종료)", args.host, args.port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("종료합니다.")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
