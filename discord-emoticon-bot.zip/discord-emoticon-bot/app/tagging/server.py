"""로컬 감정 태깅 웹페이지.

CLI로는 이미지를 볼 수 없어서, 등록된 이모티콘을 썸네일 격자로 띄우고
클릭으로 감정을 다는 로컬 전용 페이지다. 표준 라이브러리(http.server)만 쓴다.

실행:
    python -m app.tagging.server            # http://127.0.0.1:8000
    python -m app.tagging.server --port 9000

주의: 인증이 없다. localhost(127.0.0.1)에만 바인딩하는 개인용 도구다.
데이터를 수정하므로 외부에 열지 말 것(--host 0.0.0.0 사용 금지).
"""

from __future__ import annotations

import argparse
import json
import logging
import mimetypes
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from sqlalchemy import create_engine, event, func, select
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.db.models import Emoticon, Emotion, emoticon_emotions
from app.emotion.tags import normalize_tag
from app.main import setup_logging
from app.storage.local import get_storage

logger = logging.getLogger(__name__)

# 봇(async)과 같은 SQLite 파일을 sync 드라이버로 연다. WAL이라 동시 접근이 가능하다.
_engine = create_engine(
    settings.sync_url,
    future=True,
    connect_args={"timeout": 15} if settings.sync_url.startswith("sqlite") else {},
)

if settings.sync_url.startswith("sqlite"):

    @event.listens_for(_engine, "connect")
    def _sqlite_pragma(dbapi_conn, _record):  # pragma: no cover - 드라이버 콜백
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA busy_timeout=15000")
        cur.close()


_Session = sessionmaker(_engine, expire_on_commit=False)


# ── 데이터 접근(sync) ─────────────────────────────────────────
def _emotions(session: Session) -> list[Emotion]:
    return list(
        session.scalars(select(Emotion).order_by(Emotion.sort_order, Emotion.tag)).all()
    )


def _emotion_usage(session: Session) -> dict[str, int]:
    """감정 태그별로 몇 개 이모티콘에 달렸는지."""
    rows = session.execute(
        select(Emotion.tag, func.count(emoticon_emotions.c.emoticon_id))
        .outerjoin(emoticon_emotions, emoticon_emotions.c.emotion_id == Emotion.id)
        .group_by(Emotion.tag)
    )
    return {tag: int(cnt) for tag, cnt in rows}


def _emoticons(session: Session) -> list[Emoticon]:
    stmt = select(Emoticon).where(Emoticon.is_active.is_(True)).order_by(
        Emoticon.created_at.desc()
    )
    return list(session.scalars(stmt).all())


def _set_emotions(session: Session, emoticon_id: int, tags: list[str]) -> Emoticon | None:
    emoticon = session.get(Emoticon, emoticon_id)
    if emoticon is None:
        return None
    rows: list[Emotion] = []
    for raw in tags:
        tag = normalize_tag(raw)
        if not tag:
            continue
        emotion = session.scalar(select(Emotion).where(Emotion.tag == tag))
        if emotion is None:
            # 태그는 문자열로만 관리한다(아이콘 없음).
            emotion = Emotion(tag=tag, label=tag, icon="", sort_order=500)
            session.add(emotion)
            session.flush()
        if emotion not in rows:
            rows.append(emotion)
    emoticon.emotions = rows
    session.commit()
    return emoticon


def _create_emotion(session: Session, tag: str) -> Emotion | None:
    """새 감정 태그 생성. 이미 있으면 None."""
    tag = normalize_tag(tag)
    if not tag:
        return None
    if session.scalar(select(Emotion).where(Emotion.tag == tag)):
        return None
    emotion = Emotion(tag=tag, label=tag, icon="", sort_order=500)
    session.add(emotion)
    session.commit()
    return emotion


def _rename_emotion(session: Session, old_tag: str, new_tag: str) -> Emotion | None:
    """감정 태그 이름 변경. 대상 없거나 새 이름이 이미 있으면 None."""
    old_tag, new_tag = normalize_tag(old_tag), normalize_tag(new_tag)
    if not old_tag or not new_tag:
        return None
    emotion = session.scalar(select(Emotion).where(Emotion.tag == old_tag))
    if emotion is None:
        return None
    if old_tag != new_tag and session.scalar(select(Emotion).where(Emotion.tag == new_tag)):
        return None  # 새 이름이 이미 존재
    emotion.tag = new_tag
    emotion.label = new_tag
    session.commit()
    return emotion


def _delete_emotion(session: Session, tag: str) -> bool:
    """감정 태그 삭제(연결도 함께 제거). 없으면 False."""
    tag = normalize_tag(tag)
    emotion = session.scalar(select(Emotion).where(Emotion.tag == tag))
    if emotion is None:
        return False
    session.delete(emotion)  # M:N 연결은 ORM이 정리
    session.commit()
    return True


def _delete_emoticon(session: Session, emoticon_id: int) -> str | None:
    """이모티콘 개별 삭제 + 파일 제거. 삭제한 이름 반환, 없으면 None."""
    emoticon = session.get(Emoticon, emoticon_id)
    if emoticon is None:
        return None
    name = emoticon.name
    paths = [emoticon.processed_path, emoticon.original_path, emoticon.preview_path]
    storage = get_storage()
    session.delete(emoticon)
    session.commit()
    for path in paths:
        if path:
            storage.delete(path)
    return name


def _emoticon_dict(emoticon: Emoticon) -> dict:
    return {
        "id": emoticon.id,
        "name": emoticon.name,
        "emotions": sorted(e.tag for e in emoticon.emotions),
        "keywords": sorted(k.value for k in emoticon.keywords),
        "image": f"/image/{emoticon.id}",
        "pack_id": emoticon.pack_id,
    }


# ── HTTP 핸들러 ──────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    server_version = "EmoticonTagger/1.0"

    def _send(self, code: int, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code: int, payload: object) -> None:
        self._send(code, json.dumps(payload, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def _error(self, code: int, message: str) -> None:
        self._json(code, {"error": message})

    # -- GET --
    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            if path == "/":
                self._send(HTTPStatus.OK, INDEX_HTML.encode(), "text/html; charset=utf-8")
            elif path == "/api/emotions":
                with _Session() as session:
                    usage = _emotion_usage(session)
                    payload = [
                        {"tag": e.tag, "label": e.label, "count": usage.get(e.tag, 0)}
                        for e in _emotions(session)
                    ]
                self._json(HTTPStatus.OK, payload)
            elif path == "/api/emoticons":
                with _Session() as session:
                    payload = [_emoticon_dict(e) for e in _emoticons(session)]
                self._json(HTTPStatus.OK, payload)
            elif path.startswith("/image/"):
                self._serve_image(path.removeprefix("/image/"))
            else:
                self._error(HTTPStatus.NOT_FOUND, "not found")
        except Exception:  # pragma: no cover - 방어적
            logger.exception("GET %s 실패", path)
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal error")

    def _serve_image(self, raw_id: str) -> None:
        if not raw_id.isdigit():
            self._error(HTTPStatus.BAD_REQUEST, "bad id")
            return
        with _Session() as session:
            emoticon = session.get(Emoticon, int(raw_id))
            rel = emoticon.preview_path or emoticon.processed_path if emoticon else None
        if not rel:
            self._error(HTTPStatus.NOT_FOUND, "no image")
            return
        try:
            data = get_storage().read(rel)
        except (OSError, ValueError):
            self._error(HTTPStatus.NOT_FOUND, "file missing")
            return
        ctype = mimetypes.guess_type(rel)[0] or "image/png"
        self._send(HTTPStatus.OK, data, ctype)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    # -- POST --
    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        parts = path.strip("/").split("/")
        try:
            # /api/emoticons/<id>/emotions  (해당 이모티콘의 감정 교체)
            if len(parts) == 4 and parts[:2] == ["api", "emoticons"] and parts[3] == "emotions":
                self._update_emotions(parts[2])
                return
            # /api/emotions  (새 감정 태그 생성)
            if parts == ["api", "emotions"]:
                self._create_emotion()
                return
            # /api/emotions/<tag>  (감정 태그 이름 변경)
            if len(parts) == 3 and parts[:2] == ["api", "emotions"]:
                self._rename_emotion(parts[2])
                return
            self._error(HTTPStatus.NOT_FOUND, "not found")
        except (ValueError, json.JSONDecodeError) as exc:
            self._error(HTTPStatus.BAD_REQUEST, f"bad body: {exc}")
        except Exception:  # pragma: no cover
            logger.exception("POST %s 실패", path)
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal error")

    # -- DELETE --
    def do_DELETE(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        parts = path.strip("/").split("/")
        try:
            # /api/emoticons/<id>  (이모티콘 개별 삭제)
            if len(parts) == 3 and parts[:2] == ["api", "emoticons"]:
                self._delete_emoticon(parts[2])
                return
            # /api/emotions/<tag>  (감정 태그 삭제)
            if len(parts) == 3 and parts[:2] == ["api", "emotions"]:
                self._delete_emotion(parts[2])
                return
            self._error(HTTPStatus.NOT_FOUND, "not found")
        except Exception:  # pragma: no cover
            logger.exception("DELETE %s 실패", path)
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal error")

    def _update_emotions(self, raw_id: str) -> None:
        if not raw_id.isdigit():
            self._error(HTTPStatus.BAD_REQUEST, "bad id")
            return
        body = self._read_json()
        tags = body.get("emotions", [])
        if not isinstance(tags, list):
            self._error(HTTPStatus.BAD_REQUEST, "emotions must be a list")
            return
        with _Session() as session:
            emoticon = _set_emotions(session, int(raw_id), [str(t) for t in tags])
            if emoticon is None:
                self._error(HTTPStatus.NOT_FOUND, "emoticon not found")
                return
            payload = _emoticon_dict(emoticon)
        logger.info("tagged #%s -> %s", raw_id, payload["emotions"])
        self._json(HTTPStatus.OK, payload)

    def _create_emotion(self) -> None:
        tag = str(self._read_json().get("tag", "")).strip()
        with _Session() as session:
            emotion = _create_emotion(session, tag)
            if emotion is None:
                self._error(HTTPStatus.CONFLICT, "이미 있거나 빈 태그입니다")
                return
            result = {"tag": emotion.tag, "label": emotion.label, "count": 0}
        logger.info("감정 태그 생성: %s", result["tag"])
        self._json(HTTPStatus.OK, result)

    def _rename_emotion(self, old_tag: str) -> None:
        from urllib.parse import unquote

        old_tag = unquote(old_tag)
        new_tag = str(self._read_json().get("tag", "")).strip()
        with _Session() as session:
            emotion = _rename_emotion(session, old_tag, new_tag)
            if emotion is None:
                self._error(HTTPStatus.CONFLICT, "대상이 없거나 새 이름이 이미 있습니다")
                return
            result = {"tag": emotion.tag, "label": emotion.label}
        logger.info("감정 태그 이름변경: %s -> %s", old_tag, result["tag"])
        self._json(HTTPStatus.OK, result)

    def _delete_emotion(self, tag: str) -> None:
        from urllib.parse import unquote

        tag = unquote(tag)
        with _Session() as session:
            ok = _delete_emotion(session, tag)
        if not ok:
            self._error(HTTPStatus.NOT_FOUND, "태그 없음")
            return
        logger.info("감정 태그 삭제: %s", tag)
        self._json(HTTPStatus.OK, {"deleted": tag})

    def _delete_emoticon(self, raw_id: str) -> None:
        if not raw_id.isdigit():
            self._error(HTTPStatus.BAD_REQUEST, "bad id")
            return
        with _Session() as session:
            name = _delete_emoticon(session, int(raw_id))
        if name is None:
            self._error(HTTPStatus.NOT_FOUND, "emoticon not found")
            return
        logger.info("이모티콘 삭제: #%s %s", raw_id, name)
        self._json(HTTPStatus.OK, {"deleted": int(raw_id), "name": name})

    def log_message(self, fmt: str, *args) -> None:  # 요청 로그를 조용히
        logger.debug("%s - %s", self.address_string(), fmt % args)


INDEX_HTML = r"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>이모티콘 감정 태깅</title>
<style>
  :root {
    --bg: #14151a; --panel: #1d1f27; --panel-2: #262933;
    --line: #33363f; --text: #e7e9ee; --muted: #9aa0ac;
    --accent: #7aa2ff; --accent-ink: #0b1020; --ok: #4bd07a;
    --chip: #2a2e39; --chip-on: #7aa2ff;
  }
  @media (prefers-color-scheme: light) {
    :root {
      --bg:#f4f5f8; --panel:#fff; --panel-2:#f0f1f5; --line:#dcdfe6;
      --text:#1c1f26; --muted:#6b7280; --accent:#3a63d6; --accent-ink:#fff;
      --ok:#178a4c; --chip:#eceef3; --chip-on:#3a63d6;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font: 15px/1.5 system-ui, -apple-system, "Segoe UI", "Noto Sans KR", sans-serif;
  }
  header {
    position: sticky; top: 0; z-index: 5; background: var(--panel);
    border-bottom: 1px solid var(--line); padding: 14px 20px;
    display: flex; flex-wrap: wrap; gap: 12px; align-items: center;
  }
  header h1 { font-size: 17px; margin: 0 8px 0 0; font-weight: 650; }
  .count { color: var(--muted); font-size: 13px; }
  .grow { flex: 1; }
  input[type=search], input[type=text] {
    background: var(--panel-2); border: 1px solid var(--line); color: var(--text);
    border-radius: 8px; padding: 8px 11px; font-size: 14px; min-width: 180px;
  }
  input:focus { outline: 2px solid var(--accent); outline-offset: -1px; }
  label.toggle { display: inline-flex; gap: 6px; align-items: center; color: var(--muted); font-size: 14px; cursor: pointer; }
  main { padding: 20px; display: grid; gap: 16px;
    grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); }
  .card {
    background: var(--panel); border: 1px solid var(--line); border-radius: 12px;
    padding: 12px; display: flex; flex-direction: column; gap: 10px; position: relative;
  }
  .thumb {
    align-self: center; width: 128px; height: 128px; border-radius: 8px;
    /* 투명 배경 확인용 체커보드 */
    background-image:
      linear-gradient(45deg, #888 25%, transparent 25%),
      linear-gradient(-45deg, #888 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #888 75%),
      linear-gradient(-45deg, transparent 75%, #888 75%);
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0;
    background-color: #b7b7b7;
  }
  .thumb img { width: 100%; height: 100%; object-fit: contain; }
  .name { font-weight: 600; font-size: 14px; word-break: break-all; }
  .chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chip {
    border: 1px solid var(--line); background: var(--chip); color: var(--text);
    border-radius: 999px; padding: 4px 10px; font-size: 13px; cursor: pointer;
    user-select: none; transition: transform .05s ease;
  }
  .chip:hover { border-color: var(--accent); }
  .chip:active { transform: scale(.96); }
  .chip.on { background: var(--chip-on); color: var(--accent-ink); border-color: var(--chip-on); }
  /* 이모티콘 개별 삭제 X 버튼 */
  .del {
    position: absolute; top: 8px; left: 8px; width: 24px; height: 24px;
    border: none; border-radius: 6px; background: rgba(0,0,0,.35); color: #fff;
    font-size: 15px; line-height: 1; cursor: pointer; opacity: 0; transition: opacity .15s;
  }
  .card:hover .del { opacity: 1; }
  .del:hover { background: #d0454b; }
  .saved {
    position: absolute; top: 10px; right: 10px; font-size: 12px; color: var(--ok);
    opacity: 0; transition: opacity .2s ease;
  }
  .saved.show { opacity: 1; }
  /* 태그 관리 패널 */
  button.ghost {
    background: var(--panel-2); border: 1px solid var(--line); color: var(--text);
    border-radius: 8px; padding: 8px 12px; font-size: 14px; cursor: pointer;
  }
  button.ghost:hover { border-color: var(--accent); }
  .overlay {
    position: fixed; inset: 0; background: rgba(0,0,0,.5); display: none;
    align-items: flex-start; justify-content: center; padding: 60px 16px; z-index: 20;
  }
  .overlay.open { display: flex; }
  .modal {
    background: var(--panel); border: 1px solid var(--line); border-radius: 14px;
    width: 100%; max-width: 460px; padding: 20px; max-height: 80vh; overflow-y: auto;
  }
  .modal h2 { margin: 0 0 4px; font-size: 16px; }
  .modal .sub { color: var(--muted); font-size: 13px; margin-bottom: 14px; }
  .taglist { display: flex; flex-direction: column; gap: 8px; }
  .tagrow {
    display: flex; align-items: center; gap: 8px; padding: 8px 10px;
    background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;
  }
  .tagrow .tagname { flex: 1; font-size: 14px; }
  .tagrow .used { color: var(--muted); font-size: 12px; }
  .tagrow button {
    border: none; background: transparent; color: var(--muted); cursor: pointer;
    font-size: 14px; padding: 2px 6px; border-radius: 6px;
  }
  .tagrow button:hover { background: var(--line); color: var(--text); }
  .tagrow button.dtag:hover { background: #d0454b; color: #fff; }
  .modal .addrow { display: flex; gap: 8px; margin-top: 14px; }
  .modal .addrow input { flex: 1; }
  .empty { color: var(--muted); grid-column: 1/-1; text-align: center; padding: 60px 0; }
  footer { color: var(--muted); font-size: 12px; padding: 4px 20px 24px; }
</style>
</head>
<body>
<header>
  <h1>이모티콘 감정 태깅</h1>
  <span class="count" id="count">불러오는 중…</span>
  <span class="grow"></span>
  <input type="search" id="q" placeholder="이름 검색">
  <label class="toggle"><input type="checkbox" id="untagged"> 감정 없는 것만</label>
  <button class="ghost" id="manageBtn">태그 관리</button>
</header>
<main id="grid"></main>
<footer>칩을 누르면 바로 저장됩니다. 카드의 ✕ 로 이모티콘을 삭제합니다. 이 페이지는 이 컴퓨터에서만 열립니다.</footer>

<!-- 감정 태그 관리 모달 -->
<div class="overlay" id="overlay">
  <div class="modal">
    <h2>감정 태그 관리</h2>
    <div class="sub">이름을 눌러 수정, ✕ 로 삭제합니다. 삭제하면 모든 이모티콘에서 그 태그가 제거됩니다.</div>
    <div class="taglist" id="taglist"></div>
    <div class="addrow">
      <input type="text" id="addTag" placeholder="새 감정 태그 (예: 뿌듯)">
      <button class="ghost" id="addBtn">추가</button>
    </div>
    <div style="margin-top:16px;text-align:right">
      <button class="ghost" id="closeBtn">닫기</button>
    </div>
  </div>
</div>

<script>
const state = { emotions: [], emoticons: [] };
const $ = (id) => document.getElementById(id);

async function api(url, opts) {
  const res = await fetch(url, opts);
  if (!res.ok) {
    let msg = res.status;
    try { msg = (await res.json()).error || msg; } catch (_) {}
    throw new Error(msg);
  }
  return res.status === 204 ? null : res.json();
}

async function load() {
  const [emo, list] = await Promise.all([
    fetch("/api/emotions").then(r => r.json()),
    fetch("/api/emoticons").then(r => r.json()),
  ]);
  state.emotions = emo;       // [{tag,label,count}]
  state.emoticons = list;
  render();
}

function palette() {
  // 서버 감정 + 방금 추가했지만 아직 서버엔 없는 태그를 합친다
  const map = new Map(state.emotions.map(e => [e.tag, e]));
  for (const it of state.emoticons)
    for (const t of it.emotions)
      if (!map.has(t)) map.set(t, { tag: t, label: t, count: 0 });
  return [...map.values()];
}

// ── 이모티콘별 감정 저장 ──
async function toggleTag(card, it, tag) {
  const set = new Set(it.emotions);
  set.has(tag) ? set.delete(tag) : set.add(tag);
  try {
    const updated = await api(`/api/emoticons/${it.id}/emotions`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ emotions: [...set] }),
    });
    it.emotions = updated.emotions;
  } catch (e) { alert("저장 실패: " + e.message); return; }
  drawChips(card, it);
  const flag = card.querySelector(".saved");
  flag.classList.add("show");
  setTimeout(() => flag.classList.remove("show"), 900);
  if ($("untagged").checked) render();
}

function drawChips(card, it) {
  const box = card.querySelector(".chips");
  box.innerHTML = "";
  const active = new Set(it.emotions);
  for (const e of palette()) {
    const chip = document.createElement("span");
    chip.className = "chip" + (active.has(e.tag) ? " on" : "");
    chip.textContent = e.label;          // 아이콘 없이 문자열만
    chip.onclick = () => toggleTag(card, it, e.tag);
    box.appendChild(chip);
  }
}

// ── 이모티콘 개별 삭제 ──
async function deleteEmoticon(it) {
  if (!confirm(`'${it.name}' 이모티콘을 삭제할까요? 되돌릴 수 없습니다.`)) return;
  try { await api(`/api/emoticons/${it.id}`, { method: "DELETE" }); }
  catch (e) { alert("삭제 실패: " + e.message); return; }
  state.emoticons = state.emoticons.filter(x => x.id !== it.id);
  render();
}

function render() {
  const grid = $("grid");
  const q = $("q").value.trim().toLowerCase();
  const onlyUntagged = $("untagged").checked;
  grid.innerHTML = "";

  const items = state.emoticons.filter(it => {
    if (onlyUntagged && it.emotions.length) return false;
    if (q && !it.name.toLowerCase().includes(q)
        && !it.keywords.some(k => k.toLowerCase().includes(q))) return false;
    return true;
  });

  $("count").textContent = `${items.length} / ${state.emoticons.length}개`;

  if (!items.length) {
    grid.innerHTML = '<div class="empty">표시할 이모티콘이 없습니다.</div>';
    return;
  }

  for (const it of items) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML =
      '<button class="del" title="삭제">✕</button>' +
      '<span class="saved">저장됨 ✓</span>' +
      `<div class="thumb"><img loading="lazy" src="${it.image}" alt=""></div>` +
      `<div class="name"></div>` +
      '<div class="chips"></div>';
    card.querySelector(".name").textContent = it.name;
    card.querySelector(".del").onclick = () => deleteEmoticon(it);
    grid.appendChild(card);
    drawChips(card, it);
  }
}

// ── 태그 관리 모달 ──
function openManage() { renderTagList(); $("overlay").classList.add("open"); }
function closeManage() { $("overlay").classList.remove("open"); }

function renderTagList() {
  const box = $("taglist");
  box.innerHTML = "";
  const tags = [...state.emotions].sort((a, b) => a.tag.localeCompare(b.tag, "ko"));
  if (!tags.length) { box.innerHTML = '<div class="sub">태그가 없습니다.</div>'; return; }
  for (const e of tags) {
    const row = document.createElement("div");
    row.className = "tagrow";
    row.innerHTML =
      `<span class="tagname"></span><span class="used">${e.count}개</span>` +
      `<button class="rename" title="이름 변경">✎</button>` +
      `<button class="dtag" title="삭제">✕</button>`;
    row.querySelector(".tagname").textContent = e.tag;
    row.querySelector(".rename").onclick = () => renameTag(e);
    row.querySelector(".dtag").onclick = () => deleteTag(e);
    box.appendChild(row);
  }
}

async function addTag() {
  const input = $("addTag");
  const tag = input.value.trim().replace(/^#/, "");
  if (!tag) return;
  try {
    const created = await api("/api/emotions", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tag }),
    });
    state.emotions.push(created);
  } catch (e) { alert("추가 실패: " + e.message); return; }
  input.value = "";
  renderTagList(); render();
}

async function renameTag(e) {
  const next = prompt(`'${e.tag}' 의 새 이름:`, e.tag);
  if (!next || next.trim() === e.tag) return;
  const newTag = next.trim().replace(/^#/, "");
  try {
    const updated = await api(`/api/emotions/${encodeURIComponent(e.tag)}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tag: newTag }),
    });
    e.tag = updated.tag; e.label = updated.label;
  } catch (err) { alert("이름 변경 실패: " + err.message); return; }
  await load();                    // 이모티콘들의 태그도 갱신됐으므로 새로 읽는다
  openManage();
}

async function deleteTag(e) {
  const msg = e.count > 0
    ? `'${e.tag}' 태그를 삭제하면 ${e.count}개 이모티콘에서 제거됩니다. 계속할까요?`
    : `'${e.tag}' 태그를 삭제할까요?`;
  if (!confirm(msg)) return;
  try { await api(`/api/emotions/${encodeURIComponent(e.tag)}`, { method: "DELETE" }); }
  catch (err) { alert("삭제 실패: " + err.message); return; }
  await load();
  openManage();
}

$("q").addEventListener("input", render);
$("untagged").addEventListener("change", render);
$("manageBtn").addEventListener("click", openManage);
$("closeBtn").addEventListener("click", closeManage);
$("addBtn").addEventListener("click", addTag);
$("addTag").addEventListener("keydown", (ev) => { if (ev.key === "Enter") addTag(); });
$("overlay").addEventListener("click", (ev) => { if (ev.target === $("overlay")) closeManage(); });

load();
</script>
</body>
</html>
"""


def main() -> None:
    # CLI 인자 > 환경변수/.env(settings) > 기본값 순으로 적용한다.
    parser = argparse.ArgumentParser(description="이모티콘 감정 태깅 웹서버")
    parser.add_argument("--host", default=settings.tagging_host)
    parser.add_argument("--port", type=int, default=settings.tagging_port)
    args = parser.parse_args()

    setup_logging()
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        logger.warning(
            "인증이 없는 도구입니다. %s 로 열면 접근 가능한 누구나 DB를 수정할 수 있습니다.",
            args.host,
        )

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    logger.info("감정 태깅 페이지: http://%s:%d  (Ctrl+C 로 종료)", args.host, args.port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("종료합니다.")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
