"""관리용 CLI: `python -m app.cli <command>`

Web UI 없이 쓰는 관리 도구다. Discord 안에서는 `/emoticon ...` 명령을 쓴다.

  python -m app.cli init-db
  python -m app.cli preview   <url>
  python -m app.cli add       <url> <이름> [--index 1] [--emotions 황당,체념] [--keywords 아무튼]
  python -m app.cli list      [검색어]
  python -m app.cli tag       <이름> [--emotions ...] [--keywords ...] [--rename 새이름]
  python -m app.cli delete    <이름>
  python -m app.cli search    <질의>
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from app.config import settings
from app.db.base import create_all, dispose, session_scope
from app.emoticon import repository as repo
from app.emoticon import service as emoticon_service
from app.emoticon.service import DuplicateEmoticon, RegistrationError
from app.emotion.service import seed_emotions
from app.main import setup_logging
from app.search import service as search_service


def _split(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [p.strip() for p in raw.replace(",", " ").split() if p.strip()]


async def cmd_init_db(_: argparse.Namespace) -> int:
    await create_all()
    async with session_scope() as session:
        added = await seed_emotions(session)
    print(f"DB 준비 완료. 감정 태그 {added}개 추가.")
    return 0


async def cmd_preview(args: argparse.Namespace) -> int:
    result = await emoticon_service.extract_candidates(args.url)
    print(f"parser={result.parser}  후보 {len(result.candidates)}개")
    for i, candidate in enumerate(result.candidates, start=1):
        print(f"{i:3d}. {candidate.url}")
    return 0


async def cmd_add(args: argparse.Namespace) -> int:
    extracted = await emoticon_service.extract_candidates(args.url)
    if args.index > len(extracted.candidates):
        print(f"후보가 {len(extracted.candidates)}개뿐입니다.", file=sys.stderr)
        return 1
    candidate = extracted.candidates[args.index - 1]

    async with session_scope() as session:
        emoticon = await emoticon_service.register(
            session,
            name=args.name,
            image_url=candidate.url,
            source_url=extracted.source_url,
            keywords=_split(args.keywords),
            emotions=_split(args.emotions),
            referer=extracted.source_url,
        )
        print(f"등록 완료 #{emoticon.id} {emoticon.name} -> {emoticon.processed_path}")
    return 0


async def cmd_add_pack(args: argparse.Namespace) -> int:
    async with session_scope() as session:
        result = await emoticon_service.register_pack(
            session,
            url=args.url,
            base_name=args.name,
            keywords=_split(args.keywords),
            limit=args.limit,
        )
    print(f"[{result.parser}] {result.source_url}")
    if result.pack_id:
        print(f"팩 #{result.pack_id} '{result.pack_name}' 생성")
    print(result.summary)
    for item in result.added:
        print(f"  + #{item.emoticon_id} {item.name}")
    for item in result.skipped:
        print(f"  = {item.index}번 건너뜀 ({item.name}: {item.detail})")
    for item in result.failed:
        print(f"  ! {item.index}번 실패: {item.detail}")
    if result.added:
        print(f"\n감정은 태깅 페이지에서 답니다: python -m app.tagging.server")
        print(f"팩 삭제: python -m app.cli delete-pack {result.pack_id}")
    return 0 if not result.failed else 1


async def cmd_list(args: argparse.Namespace) -> int:
    async with session_scope() as session:
        found = await repo.list_all(session, query=args.query, limit=args.limit)
        total = await repo.count(session)
    for emoticon in found:
        tags = " ".join(f"#{e.tag}" for e in emoticon.emotions)
        keywords = " ".join(k.value for k in emoticon.keywords)
        print(f"#{emoticon.id:<4} {emoticon.name:<28} {tags:<30} {keywords}")
    print(f"-- {len(found)}건 표시 / 전체 {total}건")
    return 0


async def cmd_tag(args: argparse.Namespace) -> int:
    async with session_scope() as session:
        emoticon = await repo.get_by_name(session, args.name)
        if emoticon is None:
            print(f"'{args.name}' 없음", file=sys.stderr)
            return 1
        await emoticon_service.update_metadata(
            session,
            emoticon,
            name=args.rename,
            keywords=_split(args.keywords) if args.keywords is not None else None,
            emotions=_split(args.emotions) if args.emotions is not None else None,
        )
        print(f"수정 완료: {emoticon.name}")
    return 0


async def cmd_delete(args: argparse.Namespace) -> int:
    async with session_scope() as session:
        emoticon = await repo.get_by_name(session, args.name)
        if emoticon is None:
            print(f"'{args.name}' 없음", file=sys.stderr)
            return 1
        await emoticon_service.delete(session, emoticon)
    print(f"삭제 완료: {args.name}")
    return 0


async def cmd_search(args: argparse.Namespace) -> int:
    async with session_scope() as session:
        hits = await search_service.search(session, args.query)
    for hit in hits:
        print(f"{hit.score:6.1f}  {hit.emoticon.name:<28} {hit.reason}")
    if not hits:
        print("결과 없음")
    return 0


async def cmd_packs(args: argparse.Namespace) -> int:
    """팩 목록/현황 조회."""
    async with session_scope() as session:
        packs = await repo.list_packs(session, query=args.query)
        counts = await repo.pack_counts(session)
        if not packs:
            print("등록된 팩이 없습니다.")
            return 0
        for pack in packs:
            n = counts.get(pack.id, 0)
            when = pack.created_at.strftime("%Y-%m-%d %H:%M")
            print(f"#{pack.id:<4} {pack.name:<24} {n:>3}개  {when}")
            if args.verbose:
                tags = await repo.pack_tag_summary(session, pack.id)
                tagstr = ", ".join(f"{t}({c})" for t, c in tags.items()) or "감정 없음"
                print(f"       태그: {tagstr}")
    return 0


async def cmd_pack_status(args: argparse.Namespace) -> int:
    """특정 팩의 상세(구성 이모티콘 + 태깅 현황)."""
    async with session_scope() as session:
        pack = await repo.get_pack(session, args.pack_id)
        if pack is None:
            print(f"팩 #{args.pack_id} 없음", file=sys.stderr)
            return 1
        members = await repo.pack_members(session, pack.id)
        tagged = sum(1 for e in members if e.emotions)
        print(f"팩 #{pack.id} '{pack.name}'  ({len(members)}개, 태깅됨 {tagged}/{len(members)})")
        print(f"출처: {pack.source_url or '-'}")
        for e in members:
            tags = " ".join(em.tag for em in e.emotions)
            mark = "○" if not e.emotions else "●"
            print(f"  {mark} {e.name:<28} {tags}")
    return 0


async def cmd_delete_pack(args: argparse.Namespace) -> int:
    """팩 통째로 삭제."""
    async with session_scope() as session:
        pack = await repo.get_pack(session, args.pack_id)
        if pack is None:
            print(f"팩 #{args.pack_id} 없음", file=sys.stderr)
            return 1
        name = pack.name
        count = await emoticon_service.delete_pack(session, pack)
    print(f"팩 '{name}' 삭제 완료 ({count}개 이모티콘 제거)")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="app.cli", description="이모티콘 관리 CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-db", help="테이블 생성 + 감정 태그 seed").set_defaults(func=cmd_init_db)

    p = sub.add_parser("preview", help="URL에서 이미지 후보 목록 보기")
    p.add_argument("url")
    p.set_defaults(func=cmd_preview)

    p = sub.add_parser("add", help="이모티콘 등록")
    p.add_argument("url")
    p.add_argument("name")
    p.add_argument("--index", type=int, default=1, help="preview에서 본 후보 번호")
    p.add_argument("--emotions", default=None)
    p.add_argument("--keywords", default=None)
    p.set_defaults(func=cmd_add)

    p = sub.add_parser("add-pack", help="묶음 URL의 이미지를 감정 없이 한꺼번에 등록")
    p.add_argument("url")
    p.add_argument("name", help="이름 접두어 (예: 누룽이 → 누룽이_1, 누룽이_2 …)")
    p.add_argument("--keywords", default=None, help="모든 항목에 공통으로 붙일 키워드")
    p.add_argument("--limit", type=int, default=None, help="최대 등록 개수")
    p.set_defaults(func=cmd_add_pack)

    p = sub.add_parser("list", help="목록 보기")
    p.add_argument("query", nargs="?", default=None)
    p.add_argument("--limit", type=int, default=50)
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("tag", help="이름/감정/키워드 수정")
    p.add_argument("name")
    p.add_argument("--rename", default=None)
    p.add_argument("--emotions", default=None)
    p.add_argument("--keywords", default=None)
    p.set_defaults(func=cmd_tag)

    p = sub.add_parser("delete", help="삭제")
    p.add_argument("name")
    p.set_defaults(func=cmd_delete)

    p = sub.add_parser("search", help="검색 점수 확인")
    p.add_argument("query")
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("packs", help="팩 목록/현황 보기")
    p.add_argument("query", nargs="?", default=None, help="이름으로 필터")
    p.add_argument("-v", "--verbose", action="store_true", help="팩별 태그 요약 표시")
    p.set_defaults(func=cmd_packs)

    p = sub.add_parser("pack-status", help="팩 상세(구성 이모티콘 + 태깅 현황)")
    p.add_argument("pack_id", type=int)
    p.set_defaults(func=cmd_pack_status)

    p = sub.add_parser("delete-pack", help="팩 통째로 삭제")
    p.add_argument("pack_id", type=int)
    p.set_defaults(func=cmd_delete_pack)

    return parser


async def _run(args: argparse.Namespace) -> int:
    try:
        return await args.func(args)
    except (RegistrationError, DuplicateEmoticon) as exc:
        print(f"실패: {exc}", file=sys.stderr)
        return 1
    finally:
        await dispose()


def main() -> None:
    setup_logging()
    args = build_parser().parse_args()
    settings.storage_dir.mkdir(parents=True, exist_ok=True)
    raise SystemExit(asyncio.run(_run(args)))


if __name__ == "__main__":
    main()
